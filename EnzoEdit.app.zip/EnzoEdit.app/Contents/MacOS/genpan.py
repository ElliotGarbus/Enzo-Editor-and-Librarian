# Generator panel for Meris Enzo

import json
import copy
import random
import kivy

from kivy.app            import App
from kivy.lang           import Builder
from kivy.uix.label      import Label
from kivy.uix.button     import Button
from kivy.uix.behaviors  import ButtonBehavior, ToggleButtonBehavior
from kivy.uix.boxlayout  import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.spinner    import Spinner
from kivy.uix.slider     import Slider
from kivy.uix.image      import Image
from kivy.uix.popup      import Popup
from kivy.uix.checkbox   import CheckBox
from kivy.clock          import Clock
from kivy.properties     import NumericProperty, ListProperty, BooleanProperty



from Patches             import Patches
from thelibrary          import Thelibrary
import edit


kv_str = ('''
#: import Factory kivy.factory.Factory
#: set enzo_orange [251/255, 176/255, 56/255, 1]
#: set white [1, 1, 1, 1]
#: set black [0, 0, 0, 1]
#: set box_pad '2dp'
#: set box_spacing '5dp'
#: set heading_fs '25sp'
#: set fs '20sp'


<Genpan>:
    cols: 1
    padding: [dp(10), dp(10), dp(5), dp(10)]  # Left, top, right, bottom
    spacing: dp(10)
    size_hint_x: .25
    canvas.before:
        Color:
            rgba: enzo_orange
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Label:
            text: 'Patch Generator'
            font_size: heading_fs
            color: black
            size_hint_y: .05
        BoxLayout:
            orientation: 'vertical'
            padding: box_pad
            # padding: box_spacing
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width + 2,self.height, 2)
            BoxLayout:                  #******** section 1 mode control **************
                orientation: 'vertical'
                padding: box_pad
                size_hint_y: .2
                BoxLayout:
                    Label:
                        text: 'Mode'
                        font_size: fs
                        color: black
                    Spinner:
                        id: mode
                        values: 'Random', 'Swap', 'Morph',  'Sweep', 'Toe Shuffle'
                        text: 'Select'
                        #size_hint_x: 1.5
                        font_size: fs
                        on_text: root.bulkgenlock = False
                BoxLayout:
                    Button:
                        font_size: fs
                        text: 'Settings'
                        on_release: Factory.PopAlterList().open()
                        disabled: mode.text in ['Select', 'Toe Shuffle']

            BoxLayout:    # ************ section 2 Instructions ****************
                size_hint_y: .25
                padding: box_pad
                Label:
                    text: root.instr[ mode.text ]
                    text_size: self.size
                    valign: 'center'
                    font_size: '15sp'
                    color: black
                    markup: True
            BoxLayout: # ************* Section 3 Controls**********  
                orientation: 'vertical'
                size_hint_y: .55
                BoxLayout:
                    orientation: 'horizontal'
                    padding: box_pad
                    Button:
                        id: patch_one
                        text: 'Drag lib patch here'
                        font_size: fs
                        on_release:
                            app.root.ids.sm.current = 'librarian'
                            app.root.ids.sm.transition.direction = 'left'
                        disabled: mode.text in ['Select', 'Random']
                    ToggleButton:
                        id: patch_one_downisup
                        size_hint_x: .2
                        font_size: fs
                        text: 'Up' if self.state == 'normal' else 'Dn'
                        disabled: mode.text in ['Select', 'Random', 'Toe Shuffle']
                BoxLayout:
                    padding: box_pad
                    orientation: 'horizontal'
                    Button:
                        id: patch_two
                        text: 'Drag lib patch here'
                        font_size: fs
                        on_release:
                            app.root.ids.sm.current = 'librarian'
                            app.root.ids.sm.transition.direction = 'left'
                        disabled: mode.text in ['Select', 'Random']
                    ToggleButton:
                        id: patch_two_downisup
                        size_hint_x: .2
                        font_size: fs
                        text: 'Up' if self.state == 'normal' else 'Dn'
                        disabled: mode.text in ['Select', 'Random', 'Toe Shuffle']
                BoxLayout:
                    orientation: 'horizontal'
                    font_size: fs
                    padding: box_pad
                    color: black
                    Label:
                        text: 'Time(sec):'
                        font_size: fs
                        color: black
                    Spinner:
                        id: time
                        values: '3', '5', '10', '15', '20', '25', '30'
                        text: '5'
                        font_size: fs
                BoxLayout:
                    orientation: 'horizontal'
                    padding: box_pad
                    PlayIconButton:
                        #icons found at www.iconarchive.com (commercial free license)
                        source: 'Actions-media-skip-backward-icon.png'
                        disabled: False if playtoggle.state == 'normal' else True
                        opacity:  1     if playtoggle.state == 'normal' else 0.5
                        on_release:
                            root.playbackbut()
                    ToggleIconButton:
                        id: playtoggle
                        source: 'Actions-media-playback-start-icon.png' if self.state == 'normal' else 'Actions-media-playback-pause-icon.png'
                        on_state:
                            #print('in kivy code on button release')
                            app.root.ids.sm.current = 'editor'
                            app.root.ids.sm.transition.direction = 'right'
                            if self.state == 'down': root.patchnum = min ( 1 + root.patchnum, 1 + len(root.patches) )
                            root.playonebut() if self.state == 'down' else (root.clkevent and root.clkevent.cancel())
                        disabled: 
                            mode.text in ['Select'] or \
                            (not mode.text in ['Select', 'Random'] and (patch_one.text =='Drag lib patch here' or \
                            patch_two.text =='Drag lib patch here'))
                        opacity:  0.5 if self.disabled else 1
                    PlayIconButton:
                        source: 'Actions-media-skip-forward-icon.png'
                        disabled: False if playtoggle.state == 'normal' else True
                        opacity:  1     if playtoggle.state == 'normal' else 0.5
                        on_release: root.playnextbut()
                BoxLayout:
                    orientation:'vertical'
                    padding: [dp(5), dp(6), dp(5), dp(5)]  # Left, top, right, bottom
                    spacing: dp(6)
                    OnReleaseSlider:
                        orientation: 'horizontal'
                        value: root.patchnum
                        max: max(1,len(root.patches))
                        disabled: False if playtoggle.state == 'normal' else True
                        step: 1
                        min: 1
                        cursor_image: 'Enzo O 64x64.png'
                        cursor_disabled_image: 'Enzo O 64x64 gray.png'
                        on_value:
                            root.patchnum = int(self.value)
                            root.playthis()
                        on_release: root.first_slider_on_value = True                       
                    Label:
                        text: 'Patch: ' + str( root.patchnum )
                        font_size: fs
                        color: black
                BoxLayout:
                    padding: box_pad
                    Button:
                        text: 'Clear'
                        font_size: fs
                        on_release:
                            root.patches  = []
                            root.patchnum = 1
                            root.bulkgenlock = False
                
<PopAlterList>:
    title: 'Parameter Selection'
    size_hint: None,None
    width: dp(500)
    height: dp(300)
    BoxLayout:
        orientation: 'vertical'
        font_size: fs
        GridLayout:
            id: attach_mutlist
            cols: 3
        Button:
            height: 30
            size_hint_y: None
            text: 'Close'
            on_release:
                root.harvest()
                root.dismiss()
            
# from Boxlayout
<CheckItem>:
    orientation: 'horizontal'
    height: 30
    size_hint_y: None
    CheckBox:
        id: box
        size_hint_x: .2
    Label:
        id: item
        text_size: self.size
        halign: 'left'
        valign: 'center'
        
''')


class CheckItem(BoxLayout):
    pass


class PopAlterList(Popup):

    lst_order = (    # this 3 column order matches editor
         'SynthMode',            'FilterType_ToeUp',      'Tempo',
         'WaveShape',            'EnvelopeType',          'Mix_ToeUp',
         'Pitch_ToeUp',          'FilterBandwidth_ToeUp', 'DelayLevel_ToeUp',
         'Portamento_ToeUp',     'Filter_ToeUp',          'DelayFeedback_ToeUp',
         'Modulation_ToeUp',     'FilterEnvelope_ToeUp',  '',
         'RingModulation_ToeUp', 'Sustain_ToeUp'
               )
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        gen    = App.get_running_app().gen_widget
        self.checks = { _:CheckItem() for _ in gen.mutlist }

        #for c in self.checks:
        for c in self.lst_order:
            if c != '':
                self.checks[c].ids.box.active = gen.mutlist[ c ]
                self.checks[c].ids.item.text = c.replace('_ToeUp','')
                self.ids.attach_mutlist.add_widget( self.checks[c] )
            else:  # pad the entry out with a blank
                self.ids.attach_mutlist.add_widget( Label(size_hint=(None,None),size=(1,1)) )

    def harvest(self):
        gen = App.get_running_app().gen_widget
        for c in self.checks:
            gen.mutlist[ c ] = self.checks[c].ids.box.active


class PlayIconButton(ButtonBehavior, Image):
    pass


class ToggleIconButton(ToggleButtonBehavior, Image):
    pass


class OnReleaseSlider(Slider):
    def __init__(self, **kwargs):
        self.register_event_type('on_release')
        super().__init__(**kwargs)

    def on_release(self):
        pass

    def on_touch_up(self, touch):
        super().on_touch_up(touch)
        if touch.grab_current == self:
            self.dispatch('on_release')
            return True

# Some modes create new patches from \
# patches you select from the library.  Drag the patches from the library onto the buttons below.  Click the up/down \
# button to select the toe up or toe down part of the patch.

pg_instruction_select = '''[b]Auto-generate patches[/b]\n\nTime sets the transition time between patches. \
\nThe Settings button selects parameters.  [b]Select a mode.[/b]'''

pg_instruction_random = '''[b]Randomly sets patch values.[/b] \
Settings Button selects knobs for the generator.  Excluded knobs use the value \
from the editor.  \n[b]Press Play to start.[/b]'''

pg_instruction_swap = '''[b]Selects values from either of the 2 patches.[/b] \
Select up/dn for the toe-up or toe-down settings.  \
[b]Drag patches from the Library, set toe, press play.[/b]'''

pg_instruction_morph = '''[b]Selects values randomly between the 2 selected patches.[/b]\n\
Select up/dn for the toe-up or toe-down settings.  \
[b]Drag patches from the Library, set toe, press play.[/b]'''


pg_instruction_sweep = '''[b]Smoothly sweeps between the 2 selected patches.[/b]  \
Select up/dn for the toe-up or toe-down settings.  \
[b]Drag patches from the Library, set toe, press play.[/b]'''

pg_instruction_toe_shuffle = '''[b]Shuffles toe-up, toe-down and common settings.[/b] Creates up to 22 unique patches. \
[b]Drag patches from the Library, then press play[/b]'''



class Genpan(GridLayout):
    instr = { '':''} # at build, text starts as empty, so prepare
    instr['Select'] = pg_instruction_select
    instr['Random'] = pg_instruction_random
    instr['Swap']   = pg_instruction_swap
    instr['Morph']  = pg_instruction_morph
    instr['Toe Shuffle']   = pg_instruction_toe_shuffle
    instr['Sweep'] = pg_instruction_sweep

    patchnum = NumericProperty(1)
    patches  = ListProperty( [] )
    clkevent = 0  # placeholder
    first_slider_on_value = BooleanProperty(True)  # first time for the on_value event for the slider since last release
    bulkgenlock           = BooleanProperty( False )

    # initial mutation list
    mutlist  = { _:True for _ in Patches.emptybdict().keys() if 'ToeDown' not in _ }
    mutlist[ 'Mix_ToeUp' ] = False
    mutlist[ 'SynthMode' ] = False


    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        app   = App.get_running_app()
        app.root.ids.sm.current = 'librarian'
        app.root.ids.sm.transition.direction = 'left'
        self.slider_time_filter = None  # holds the schedule for the slider

    def send_patch_to_enzo(self, patch):
        #print('entering send patch')
        app   = App.get_running_app()
        bpat  = Patches.bdict2blist(patch)
        #print('Send patch: ', bpat)
        app.enzo_midi.preview_patch( bpat )
        
    def generate_patch(self):
        #
        # Notice there are several exits from this method.
        # There is an exit if the bulk gen lock is set
        # There is an exit if not enough info to gen (the not ok exit)
        # There is an exit after bulk generation (Toe shuffle or Sweep)
        # There is an exit in linear if the two patches are too similar
        # There is an exit at the end of rand/morph/comb generation
        #
        # return False if we did not gen, otherwise return True
        #
        #
        if self.bulkgenlock: return False
        app = App.get_running_app()
        ui = Patches.blist2bdict(app.root.ids.sm.get_screen('editor').ids.editor.read_ui_knobs())
        for i in self.mutlist:
            ui[ i ] = self.myCannon( i, ui[ i ] )
        #print ('cannonical UI: ', ui )

        ok  = (   ( (self.ids.patch_one.text in app.mylib ) and
                    (self.ids.patch_two.text in app.mylib ) )
               or (self.ids.mode.text == 'Random' )
               )
        if not ok: return False   # silently refuse to go on without enough info

        res = copy.deepcopy( ui  )

        if (self.ids.patch_one.text in app.mylib ):
            one = copy.deepcopy( app.mylib.get_patch(  self.ids.patch_one.text  ) )
            if self.ids.patch_one_downisup.state == 'down' and (self.ids.mode.text != 'Toe Shuffle'):
                self.copydown2up(one)

        if (self.ids.patch_two.text in app.mylib ):
            two = copy.deepcopy( app.mylib.get_patch(  self.ids.patch_two.text  ) )
            if self.ids.patch_two_downisup.state == 'down' and (self.ids.mode.text != 'Toe Shuffle'):
                self.copydown2up(two)


        #----Begin bulk generation for Toe Shuffle -----------
        if self.ids.mode.text == 'Toe Shuffle':    # toe shuffle is a bulk generation
            self.bulkgenlock = True

            ups   = [ k for k in Patches.toe_up2down.keys() ]
            downs = [ Patches.toe_up2down[ i ] for i in ups ]
            fixed = [ 'WaveShape', 'SynthMode', 'EnvelopeType', 'Tempo' ]
            #print ('Ups: ', ups)
            #print ('Down:', downs)
            sequences = (  [ one[ i ] for i in ups   ]
                        ,  [ one[ i ] for i in downs ]
                        ,  [ two[ i ] for i in ups   ]
                        ,  [ two[ i ] for i in downs ]
                        )
            for *seq1, in sequences:
                #print ('Seq1: ', seq1)
                for *seq2, in sequences:
                    #print ('  Seq2: ', seq2)
                    if seq1 == seq2: continue
                    for ndx,item in enumerate(ups):
                        res[ item ] = seq2[ ndx ]
                    for ndx,item in enumerate(downs):
                        res[ item ] = seq1[ ndx ]
                    for item     in fixed:
                        res[ item ] = one[ item ]
                    if all([ res[_]==one[_] for _ in res ]): continue #skip one
                    self.patches.append( copy.deepcopy(res) )
            for *seq1, in sequences:
                for *seq2, in sequences:
                    if seq1 == seq2: continue
                    for ndx,item in enumerate(ups):
                        res[ item ] = seq2[ ndx ]
                    for ndx,item in enumerate(downs):
                        res[ item ] = seq1[ ndx ]
                    for item     in fixed:
                        res[ item ] = two[ item ]
                    if all([ res[_]==two[_] for _ in res ]): continue #skip two
                    self.patches.append( copy.deepcopy(res) )
            return True
        #----End bulk generation for Toe Shuffle -----------


        #Now cannon-ize one and two
        if (self.ids.patch_one.text in app.mylib ):
            for _ in self.mutlist:
                one[ _ ] = self.myCannon( _, one[ _ ] )
        if (self.ids.patch_two.text in app.mylib ):
            for _ in self.mutlist:
                two[ _ ] = self.myCannon( _, two[ _ ] )

        #----Begin bulk generation for Sweep -----------
        #
        # in order to correctly treat components where a range of values
        # map to a single device setting, we convert the values into
        # 'index space'.  In 'index space' there is a one to one correspondance
        # from an index to a device setting.
        # We transform:
        #  enzoCannon->myCannon->Index space (Operate)-->myCannon-->enzoCannon
        # 
        # To operate:
        # After transforming to index space 
        # we compute the (signed) delta to apply each step
        # Note delta is a vector, with a delta for each component
        # The transformation of patch one to patch two occurs
        # over maxstep transitions.  The following should hold: 
        #       one + delta * maxstep   =   two
        # Each step generates a patch that is delta different from the last
        # patch is delta different from the last step
        #
        # Note that if patches are too similar and maxsteps is 0,
        # no transition can be done.  Hence, this code has a return exit
        #
        if self.ids.mode.text == 'Sweep':    # Sweep is a bulk generation

            # transform to 'index space'
            ndx1  = { c:self.getCannonRange(c).index( one[c] ) for c in self.mutlist }
            ndx2  = { c:self.getCannonRange(c).index( two[c] ) for c in self.mutlist }

            # compute the (signed) deltas 
            delta   = { c:(ndx2[c] - ndx1[c])                  for c in self.mutlist }
            maxstep = max( [ max(delta.values()) , abs( min( delta.values() ) ) ] )

            if maxstep == 0: return False   # patches not sufficently different
            self.bulkgenlock = True

            # compute the (signed) delta to apply each step
            for i in self.mutlist:
                delta[i] = float( delta[i] ) / float( maxstep )

            ndxres = copy.deepcopy( ndx1 )   # start at one (in index space)
            for step in range(maxstep):
                for c in self.mutlist:
                    if self.mutlist[c]:
                        ndxres[ c ] += delta[ c ]
                        index        = int(ndxres[ c ] + 0.5 )
                        res   [ c ]  = self.getCannonRange(c)[ index ]
                    else:
                        res   [ c ]  = ui[ c ]
                    res[ c ] = self.enzoCannon( c, res[ c ] )

                self.copyup2down(res)
                self.patches.append( copy.deepcopy(res) )   
            return True

        #----End bulk generation for Sweep -----------

        for c in self.mutlist:
            if self.mutlist[c]:
                if   self.ids.mode.text == 'Swap':
                    res[ c ] = random.choice([  one[c],  two[c] ])
                elif self.ids.mode.text == 'Morph':
                    (left, right) = sorted( [ one[c], two[c] ] )
                    while True:
                        res[ c ] = random.choice( self.getCannonRange(c ) )
                        if (res[c] >= left) and (res[c] <= right): break
                elif self.ids.mode.text == 'Random':
                    res[ c ] = random.choice( self.getCannonRange(c ) )
                else: print ('WOOPS!  unimplmented mode ',self.ids.mode.text)
            else:
                res[ c ] = ui[ c ]

        # convert back to Enzo Cannon to avoid bugs in GUI or from Enzo device
        for i in self.mutlist:
            res[ i ] = self.enzoCannon( i, res[ i ] )

        # copy ToeUp to ToeDown
        self.copyup2down(res)
        self.patches.append( res )   # Save patch to play later
        return True

    @staticmethod
    def copyup2down(patch):
        # copy ToeUp to ToeDown
        for _ in Patches.toe_up2down.keys():
            patch[ Patches.toe_up2down[ _ ] ] = patch[ _ ]

    @staticmethod
    def copydown2up(patch):
        # copy ToeDown to ToeUp
        for _ in Patches.toe_up2down.keys():
            patch[ _ ] = patch[ Patches.toe_up2down[ _ ] ]

    def playonebut(self):
        #print('entering playonebut and self is', self)
        #Check that we did not close the GUI pane
        #  ingore possible race if pane closes and re-opens while we run
        if App.get_running_app().gen_widget is None:
            return 

        justgenerated = False
        # Could make this a while if we knew that generate_patch always did something
        if ( self.patchnum > len( self.patches ) ):
            justgenerated = self.generate_patch()
        if ( self.patchnum > len( self.patches ) ):
            return   #  essentially a user error condition if generate did not do something

        if justgenerated:
            self.send_patch_to_enzo(  self.patches[ self.patchnum - 1 ] )
        self.clkevent = Clock.schedule_once( self.playnext, int( self.ids.time.text ) )

    def playnext(self,dt):   # call back
        #print('entering playnext')
        self.patchnum += 1
        self.playonebut()
        return False

    def playthis(self):   # invoked from slider
        if self.first_slider_on_value:
            self.first_slider_on_value = False  # set to True when slider is released
            self.slider_time_filter = Clock.schedule_once(self.schedule_send_patch_to_enzo, .250)
        else:
            self.slider_time_filter()

    def schedule_send_patch_to_enzo(self,dt):  # Scheduled from playthis() to reduce num of patches sent on_value
        if self.patchnum < len(self.patches):
            self.send_patch_to_enzo(self.patches[self.patchnum - 1])

    def playnextbut(self):  # invoked from play next button
        if self.clkevent: self.clkevent.cancel()
        if ( self.patchnum < len( self.patches ) ):
            self.patchnum += 1

    def playbackbut(self):  # invoked from play previous button
        if self.clkevent: self.clkevent.cancel()
        if self.patchnum > 1:
            self.patchnum -= 1

    #
    # for generator uses, we need the value in a component with a
    # range to be the smallest value.  That is, the value must
    # be the left hand end of the range.  We call this "myCannon"
    #
    # For some components, this is inconsistant with what Enzo would
    # return.  This inconsistancy might (or will) break the GUI knobs,
    # and might stress out the Enzo device itself.  Thus some components
    # may need to be transformed back to a 'enzoCannon'.
    #
    pitchlefts = ( 0,    0x01, 0x0C, 0x10, 0x14, 0x18, 0x1c,
                   0x20, 0x24, 0x28, 0x2C, 0x30, 0x34, 0x38,
                   0x48, 0x4C, 0x50, 0x54, 0x58, 0x5C, 0x60,
                   0x64, 0x68, 0x6C, 0x70, 0x74, 0x7f )
    def getCannonRange( self, component ):
        """ returns a tuple for my cannonical range allowed for a given component """
        if (component in ['Pitch_ToeUp', 'Pitch_ToeDown']):
            return  self.pitchlefts
        if (component in ['FilterType_ToeDown', 'FilterType_ToeUp' ]):
            return   ( 0,    0x04, 0x21, 0x3c, 0x58, 0x74 )
        if (component in [ 'WaveShape', 'EnvelopeType' ]):
            return   ( 0,    64 )
        if (component in [ 'SynthMode' ]):
            return   ( 0,    32,   64,   96 )
        if (component in [ 'Tempo' ]):
            return tuple( range(1,128) )
        return tuple( range(128) )

    def myCannon( self, component, val ):
        """ transforms val to be the lowest value that retains the same enzo meaning """

        if (component in ['Pitch_ToeUp', 'Pitch_ToeDown']):
            while (val not in self.pitchlefts):
                val -= 1
            return val
        if (component in ['FilterType_ToeDown', 'FilterType_ToeUp' ]):
            if   val < 4:    return 0
            elif val < 0x21: return 0x4
            elif val < 0x3c: return 0x21
            elif val < 0x58: return 0x3c
            elif val < 0x74: return 0x58
            else:            return 0x74
        if (component in [ 'WaveShape', 'EnvelopeType' ]):
            if   val < 64:   return 0
            else:            return 64
        if (component in [ 'SynthMode' ]):
            if   val < 32:   return 0
            elif val < 64:   return 32
            elif val < 96:   return 64
            else:            return 96
        return val

    @staticmethod
    def enzoCannon( component, val ):
        """ transforms a myCannon val to the value enzo would return for given component """
    #
    # Assume val adheres to myCannon. 
    #
        if (component in [ 'WaveShape', 'EnvelopeType' ]):
            return { 0:0, 64:0x7f }[ val ]
        if (component in [ 'SynthMode' ]):
            return { 0:0, 32:63,   64:95,   96:127   }[ val ]
        return val

#
# called from main during motion up processing when a patch
# is dragged to the gen panel.
#
def do_drag_drops( touch ):
    app =  App.get_running_app()
    gpan = app.gen_widget
    if ( gpan.ids.patch_one.collide_point( *gpan.ids.patch_one.to_widget(*touch.pos,relative=False))):
        #print('dropping ',app.trklab.text ,' to one')
        gpan.ids.patch_one.text = app.trklab.text
        gpan.bulkgenlock = False
    if ( gpan.ids.patch_two.collide_point( *gpan.ids.patch_two.to_widget(*touch.pos,relative=False))):
        #print('dropping ',app.trklab.text ,' to two')
        gpan.ids.patch_two.text = app.trklab.text
        gpan.bulkgenlock = False


Builder.load_string( kv_str )


