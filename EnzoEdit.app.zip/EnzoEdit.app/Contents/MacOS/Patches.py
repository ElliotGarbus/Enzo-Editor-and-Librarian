#
# convert between byte list patch format (blist)
# and dictionary patch format (bdict)
#


class Patches:
    posits = {
        "Pitch_ToeUp": 9, "Filter_ToeUp": 10,
        "Mix_ToeUp": 11, "Sustain_ToeUp": 12,
        "FilterEnvelope_ToeUp": 13, "Modulation_ToeUp": 14,
        "Portamento_ToeUp": 15, "FilterType_ToeUp": 16,
        "DelayLevel_ToeUp": 17, "RingModulation_ToeUp": 18,
        "FilterBandwidth_ToeUp": 19, "DelayFeedback_ToeUp": 20,

        "WaveShape": 22, "SynthMode": 23,
        "EnvelopeType": 24, "Tempo": 25,

        "Pitch_ToeDown": 26, "Filter_ToeDown": 27,
        "Mix_ToeDown": 28, "Sustain_ToeDown": 29,
        "FilterEnvelope_ToeDown": 30, "Modulation_ToeDown": 31,
        "Portamento_ToeDown": 32, "FilterType_ToeDown": 33,
        "DelayLevel_ToeDown": 34, "RingModulation_ToeDown": 35,
        "FilterBandwidth_ToeDown": 36, "DelayFeedback_ToeDown": 37
    }
    toe_up2down = {'Pitch_ToeUp'            :'Pitch_ToeDown'
                  ,'Filter_ToeUp'           :'Filter_ToeDown'
                  ,'Mix_ToeUp'              :'Mix_ToeDown'
                  ,'Sustain_ToeUp'          :'Sustain_ToeDown'
                  ,'FilterEnvelope_ToeUp'   :'FilterEnvelope_ToeDown'
                  ,'Modulation_ToeUp'       :'Modulation_ToeDown'
                  ,'Portamento_ToeUp'       :'Portamento_ToeDown'
                  ,'FilterType_ToeUp'       :'FilterType_ToeDown'
                  ,'DelayLevel_ToeUp'       :'DelayLevel_ToeDown'
                  ,'RingModulation_ToeUp'   :'RingModulation_ToeDown'
                  ,'FilterBandwidth_ToeUp'  :'FilterBandwidth_ToeDown'
                  ,'DelayFeedback_ToeUp'    :'DelayFeedback_ToeDown'
                  }

    @staticmethod
    def blist2bdict(bl):
        bd = {}
        for b in Patches.posits:
            bd[b] = bl[Patches.posits[b] - 9]
        return bd

    @staticmethod
    def bdict2blist(bd):
        bl = [None for _ in range(38 - 9)]
        bl[21 - 9] = 0x7f  # shove in the mystery byte
        for b in Patches.posits:
            bl[Patches.posits[b] - 9] = bd[b]
        return bl

    @staticmethod
    def emptybdict():
        bd = {}
        for b in Patches.posits:
            bd[b] = 0
        return bd
