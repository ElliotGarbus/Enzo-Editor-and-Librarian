import re
import json

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.properties import StringProperty

from Patches import Patches


class Liblin(BoxLayout):
    myname = StringProperty('')
    mydesc = StringProperty('')


class Thelibrary:

    def __init__(self):
        self.thelib = {}
        self.reverselib = {}
        self.liblayout = []
        self.searchbox = 0  # placeholder
        self.libscrollbox = 0  # placeholder
        self.prebuts = None

    def __contains__(self, thing):
        return (thing in self.thelib
                or thing in self.reverselib
                )

    def get_headless_patch(self, e):
        return Patches.bdict2blist(self.thelib[e]['patch'])

    def get_patch(self, e):
        return (self.thelib[e]['patch'])

    def check_database(self):
        broken = False
        for e in self.thelib:
            t = tuple(self.get_headless_patch(e))
            broken = broken or t in self.reverselib
            self.reverselib[t] = e
        if broken:
            self.thelib = {}
            self.reverselib = {}

    def write_database(self):
        lname = App.get_running_app().config.get('Enzo', 'lib_dir') + '/library.json'
        json.dump(self.thelib,
                  open(lname, 'w'),
                  indent=2)

    def prebut_list(self):
        return self.prebuts.values()

    def read_database(self, r):
        self.prebuts = {c.preset: c for c in r.walk() if hasattr(c, 'preset')}
        lname = App.get_running_app().config.get('Enzo', 'lib_dir') + '/library.json'
        try:
            self.thelib = json.load(open(lname, 'r'))
        except:
            self.thelib = {}
        self.check_database()
        self.searchbox = r.ids.sm.get_screen('librarian').ids.search_box
        self.libscrollbox = BoxLayout(orientation='vertical', height='210dp', size_hint_y=None, padding='4dp', spacing='2dp')
        self.libscrollbox.bind(minimum_height=self.libscrollbox.setter('height'))
        for _ in self.thelib.keys():
            self.liblayout.append(Liblin())
            self.libscrollbox.add_widget(self.liblayout[-1])
        s = ScrollView(do_scroll_x=False, bar_width='20dp', scroll_type=['bars', 'content'])
        s.add_widget(self.libscrollbox)
        r.ids.sm.get_screen('librarian').ids.attach.add_widget(s)
        self.rename_lib()

    def order_lib(self):
        search_str = self.searchbox.text.lower()
        if len(search_str) > 0:
            return sorted(self.thelib.keys(),
                          key=lambda x: (x.lower() + self.thelib[x]['descr'].lower()).count(search_str), reverse=True)
        return sorted(self.thelib.keys(), key=lambda x: x)

    def rename_lib(self):
        for e, lb in zip(self.liblayout, self.order_lib()):
            e.myname = lb
            e.mydesc = (self.thelib[lb]['descr'])
        self.write_database()

    def update_entry_description(self, entry, txt):
        self.thelib[entry]['descr'] = txt

    def delete_entry(self, entry):
        # if these fail, I am a broken app
        del self.reverselib[tuple(self.get_headless_patch(entry))]
        del self.thelib[entry]
        self.libscrollbox.remove_widget(self.liblayout.pop())
        self.rename_lib()

    def add_entry(self, e, tup, entry):
        self.thelib[e] = entry
        self.reverselib[tuple(tup)] = e
        self.liblayout.append(Liblin())
        self.libscrollbox.add_widget(self.liblayout[-1])

    def add_patch(self, e, tup):
        ent = {'patch': Patches.blist2bdict(tup), 'descr': ''}
        self.add_entry(e, tup, ent)
        self.rename_lib()

    def add_patch_and_desc(self, e, tup, desc):
        ent = {'patch': Patches.blist2bdict(tup), 'descr': desc}
        self.add_entry(e, tup, ent)
        self.rename_lib()

    def get_name_of(self, patch):
        if patch in self:
            return self.reverselib[tuple(patch)]
        return 'Unnamed'

    def set_preset_label(self, num, patch):
        if num in self.prebuts.keys():
            self.prebuts[num].patchname = self.get_name_of(patch)

    def namefor(self, e):
        newe = e
        if e in self:
            i = 1
            while (e + '_' + str(i)) in self:
                i += 1
            newe = e + '_' + str(i)
        return newe

    def loadfiles(self, namelist):
        app_ptr = App.get_running_app()
        wlist = []
        try:
            for name in namelist:
                if '.json' in name:
                    ent = self.read_json(name)
                    for e in ent.keys():
                        t = tuple(Patches.bdict2blist(ent[e]['patch']))
                        if t in self:
                            wlist.append(e)
                        else:
                            self.add_entry(self.namefor(e), t, ent[e])
                    self.rename_lib()
                elif '.syx' in name:
                    sname = re.sub('.*/', '', name)  # strip down file name
                    sname = re.sub(r'.*\\', '', sname)  # strip down file name
                    sname = re.sub('.syx', '', sname)  # to just the name part
                    t = tuple(self.read_sysx(name))
                    if t in self:
                        wlist.append(sname)
                    else:
                        self.add_patch(self.namefor(sname), t)

            if len(wlist) > 0:
                app_ptr.error_popup.ids.message.text = (
                        'Sounds already in library: '
                        + ', '.join(wlist)
                        + '.  Library items must be unique sounds.'
                        + '   These patch(es) is/are ignored.'
                )
                app_ptr.error_popup.open()
        except:
            app_ptr.error_popup.ids.message.text = (
                    'Problems with opening or reading file.  '
                    + 'File is ignored.'
            )
            app_ptr.error_popup.open()

    def read_json(self, f):
        return json.load(open(f, 'r'))

    def read_sysx(self, f):
        entries = [b for b in open(f, 'rb').read()]
        if (entries[1] == 0
                and entries[2] == 0x20
                and entries[3] == 0x10
                and entries[5] == 0x1
                and entries[6] == 0x3):
            return entries[9:-1]
        raise IOError
