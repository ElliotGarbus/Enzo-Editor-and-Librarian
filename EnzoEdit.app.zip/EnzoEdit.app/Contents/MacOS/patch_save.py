"""Dialog to save patches to the Enzo Preset slots and the library"""
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.properties import ListProperty

Builder.load_string('''
<PatchSavePopup>:
    title:'Save the Current Patch to the Library and a Preset Slot'
    size_hint: (None, None)
    size: (dp(800),dp(400))
    BoxLayout:
        orientation:'vertical'
        Label:
            text:'Provide a Name and Description for the Patch'
            font_size: '25sp'          
        ValidFilenameInput:
            id: patch_name
            multiline: False
            hint_text: 'Name'
            size_hint: (None,None)
            size: (dp(400),dp(30))
            on_text: input_warning.text = 'Name is Already in Library, Change the Name' if self.text in app.mylib else ''
        TextInput:
            id: patch_description
            multiline: False
            hint_text: 'Description'
            size_hint: (None,None)
            size: (dp(750),dp(30))
        Label:
            id: input_warning
            color: [1, 0, 0, 1]
            font_size: '25sp'
            text:'' 
            text_size: self.size
            halign: 'left'
            valign: 'center'     
        BoxLayout: 
            #size_hint_y: 0.4
            # orientation: 'vertical'
            Label:
                text:''
                #size_hint_x:.1
            Label:
                padding_x: dp(5)
                text: 'Save to Preset:'
                font_size: '20sp'
                text_size: self.size
                halign: 'right'
                valign: 'center'
            Spinner:
                #size_hint_x:.25
                id: preset_slot
                text: 'None'
                values: ['None'] + [str(x) for x in range(1,17)]
            Label:
                text:''
        BoxLayout:
            #size_hint_y: 0.2
            Label:
                text:''    
        BoxLayout:
            Button:
                text: 'Save'
                disabled: True if patch_name.text in app.mylib else False
                on_release: root.write_entry()
            Button:
                text:'Cancel'
                on_release: root.dismiss()
        ''')


class PatchSavePopup(Popup):
    """Patch Save Dialog and Control"""
    headless_patch = ListProperty([])

    def write_entry(self):
        a = App.get_running_app()
        # print(f'name: {self.ids.patch_name.text}, patch: {self.headless_patch} and Description: {self.ids.patch_description.text}')
        a.mylib.add_patch_and_desc(self.ids.patch_name.text, self.headless_patch, self.ids.patch_description.text)
        if self.ids.preset_slot.text != 'None':
            preset = int(self.ids.preset_slot.text)
            # print(f'preset:{preset}, headless_patch: {self.headless_patch}')
            a.enzo_midi.write_patch(preset, self.headless_patch)
            a.mylib.set_preset_label(preset, tuple(self.headless_patch))
        self.dismiss()


class ValidFilenameInput(TextInput):
    invalid_set = r"/\*:|'.?" + '"<>'

    def insert_text(self, substring, from_undo=False):
        patch_name = [c for c in substring if c not in self.invalid_set]
        s = ''.join(patch_name)
        return super().insert_text(s, from_undo=from_undo)
