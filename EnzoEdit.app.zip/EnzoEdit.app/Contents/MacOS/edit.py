# Editor Screen for Meris Enzo

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.gridlayout import GridLayout
from kivy.uix.spinner import Spinner
from kivy.uix.slider import Slider


kv_str = ('''
#: import CircleKnob circleknob
#: import XYKnob xyknob
#: set box_pad '2dp'
#: set box_spacing '5dp'
#: set enzo_orange [251/255, 176/255, 56/255, 1]
#: set white [1, 1, 1, 1]
#: set black [0, 0, 0, 1]
#: set heading_fs '25sp'
#: set fs '20sp'

<Editor>:
    cols: 3
    padding: [dp(5), dp(10), dp(10), dp(10)]
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: enzo_orange
        Rectangle:
            pos: self.pos
            size: self.size
    #------------ COL 1 Mode and Waves -------------
    BoxLayout:
        orientation: 'vertical'
        Label:
            text: 'Mode & Wave'
            font_size: heading_fs
            color: black
            size_hint_y: .05
        BoxLayout:
            orientation: 'vertical'
            padding: box_pad
            spacing: box_spacing
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width + 2,self.height, 2)
            BoxLayout:
                padding: box_pad
                orientation: 'vertical'
                BoxLayout:
                    Label:
                        text: '         Mode'
                        font_size: fs
                        color: black
                    SynthModeSpinner:    # Synth Mode
                        id: synth_mode
                        text: 'Poly'
                        font_size: fs
                        values: ['Dry', 'Mono', 'Arp', 'Poly' ]
                        on_text: app.enzo_midi.cc(app.cc.synth_mode, (0, 63, 95, 127)[self.values.index(self.text)])
                        disabled: True if exp_pedal.state == 'down' else False
                BoxLayout:
                    Label:
                        text: 'Wave Shape'
                        color: black
                        font_size: fs
                    WaveShapeSpinner:
                        id: synth_waveshape
                        text:'Saw'
                        font_size: fs
                        values: ['Saw', 'Square']
                        disabled: True if synth_mode.text == 'Dry' or exp_pedal.state == 'down' else False
                        on_text: app.enzo_midi.cc(app.cc.synth_waveshape, self.values.index(self.text) * 127)
        
            CircleKnob:
                id: pitch
                text: 'Pitch'
                values: root.pitch_values
                right_click_value: 64
                on_mouse_set_value: app.enzo_midi.cc(app.cc.pitch, self.value) 
            CircleKnob:
                id: portamento
                text:'Env Pitch Bend' if synth_mode.text == 'Dry' else 'Portamento' 
                on_mouse_set_value: app.enzo_midi.cc(app.cc.portamento, self.value)
            CircleKnob:
                id: modulation
                text: 'Modulation(Detune)' if synth_mode.text != 'Dry' else 'Modulation(Delay)'
                on_mouse_set_value: app.enzo_midi.cc(app.cc.modulation, self.value)
            CircleKnob:
                id: ring_modulation
                text: 'Ring Modulation'
                on_mouse_set_value: app.enzo_midi.cc(app.cc.ring_mod, self.value)
        
    # ------ Col 2 Filer and Env --------
    BoxLayout:
        orientation: 'vertical' 
        Label:
            text: 'Filter & Envelope'
            font_size: heading_fs
            color: black
            size_hint_y: .05
        BoxLayout:
            orientation: 'vertical'
            padding: box_pad
            spacing: box_spacing
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width + 2,self.height, 2)
            BoxLayout:
                padding: box_pad
                size_hint_y: 1/6
                orientation: 'vertical'
                BoxLayout:
                    Label: 
                        text: 'Filter Type'
                        font_size: fs 
                        color: black
                    FilterTypeSpinner:
                        id: filter_type
                        text: 'Ladder LP'
                        font_size: fs
                        values: ['Ladder LP', 'Ladder BP', 'Ladder HP', 'State Var LP','State Var BP','State Var HP']
                        on_text: app.enzo_midi.cc(app.cc.filter_type, (0x00, 0x04, 0x21, 0x3C, 0x58, 0x74)[self.values.index(self.text)] )
                BoxLayout:
                    Label: 
                        text:'Env Type'
                        font_size: fs
                        color: black
                    EnvTypeSpinner: 
                        id: envelope_type
                        text:'Triggered'
                        font_size: fs
                        values: ['Triggered', 'Follower']
                        on_text: app.enzo_midi.cc(app.cc.envelope_type, (0x00, 0x7f)[self.values.index(self.text)])
                        disabled: True if exp_pedal.state == 'down' else False   
            XYKnob: 
                id: filter
                text:       'Filter'
                label_x:    'CUTOFF'
                label_y:    'RESO'
                labeloffset: 0
                value_x:     0
                value_y:     0
                size_hint_y: 2/6
                on_mouse_set_value_x: app.enzo_midi.cc(app.cc.filter, self.value_x)
                on_mouse_set_value_y:app.enzo_midi.cc(app.cc.filter_bw, self.value_y)  
            
            CircleKnob:
                id: filter_envelope
                text: 'Filter Env'
                values: root.filter_env_values if envelope_type.text == 'Triggered' else root.filter_follower_env_values
                size_hint_y: 1/6
                on_mouse_set_value: app.enzo_midi.cc(app.cc.filter_env, self.value)
            CircleKnob:
                id: sustain
                text: 'Compressor' if synth_mode.text == 'Dry' else 'Sustain'
                size_hint_y: 1/6
                on_mouse_set_value: app.enzo_midi.cc(app.cc.sustain, self.value)
  
    # -----------Col 3 Mix & Delay -----------------
    BoxLayout:
        orientation: 'vertical'      
        Label:
            text: 'Exp, Tempo, Mix & Delay'
            color: black
            font_size: heading_fs
            size_hint_y: .05
        BoxLayout:
            orientation: 'vertical'
            padding: box_pad
            spacing: box_spacing
            canvas.after:
                Color:
                    rgba: black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width + 2,self.height, 2)
            BoxLayout:             
                BoxLayout:
                    padding: box_pad
                    orientation: 'vertical'
                    ToggleButton:    
                        id: toe_up
                        text: 'Toe is Up' if self.state == 'normal' else 'Toe is Down'
                        font_size: fs
                        on_release: root.set_toe(0) if self.state == 'normal' else root.set_toe(0x7F)
                        disabled: exp_pedal.state == 'normal'
                BoxLayout:
                    orientation: 'vertical'
                    padding: box_pad
                    Button:
                        font_size: fs
                        halign: 'center'
                        text: 'Copy Toe Up\\nto Toe Down'
                        on_release: root.copy_toe_up_to_down()
                        disabled: exp_pedal.state == 'normal'
                    ToggleButton:
                        id: exp_pedal
                        font_size:fs
                        text: 'Prgm Exp Pedal'
                        on_release: if toe_up.state == 'normal': root.set_toe(0)  
                        on_press: toe_up.state = 'normal'            
            BoxLayout:
                canvas.after:
                    Color:
                        rgba: black
                    Line:
                        width:dp(1)
                        # rounded_rectangle: (self.pos[0] + 4, self.pos[1], self.width - 6, self.height - 4, 2)
                        rounded_rectangle: (self.pos[0] + 4, self.pos[1], self.width - 6, self.height, 2)
                TempoSlider:
                    id: tempo
                    orientation: 'vertical'
                    min: -127
                    max: -1
                    value: -50
                    step: 1
                    cursor_image: 'Enzo O 64x64.png'
                    cursor_disabled_image: 'Enzo O 64x64 gray.png'
                    on_value: app.enzo_midi.cc(app.cc.tempo, int(self.value) * -1)
                    disabled: True if exp_pedal.state == 'down' else False
                BoxLayout:
                    orientation:'vertical'                     
                    Label:
                        text: 'TEMPO'
                        color: black
                        font_size: fs
                    Label:
                        font_size: fs
                        color: black
                        text: '0' if tempo.value == 0 else str(round(6000/int(tempo.value) * -1)) + ' BPM' 
                    Label:
                        text:str(abs(int(tempo.value)*10)) +' ms' 
                        font_size: fs
                        color: black
                BoxLayout:
                    orientation: 'vertical'
                    Label:
                        text: ''
                        size_hint_y: .2    
                    BoxLayout:
                        Label:
                            text:''
                            size_hint_x: .2
                        Button:
                            text: 'Tap'
                            font_size: fs
                            on_press: app.enzo_midi.tap()
                        Label:
                            text:''
                            size_hint_x: .2
                    Label:
                        text:''
                        size_hint_y: .2
                    
            CircleKnob:
                id: mix
                text: 'Mix'
                right_click_value: 64
                on_mouse_set_value: app.enzo_midi.cc(app.cc.mix, self.value)
      
            CircleKnob:
                id: delay_level
                text: 'Delay Level'
                values: root.delay_level_values
                on_mouse_set_value: app.enzo_midi.cc(app.cc.delay_level, self.value)
      
            CircleKnob:
                id: delay_feedback
                text: 'Delay Feedback'
                on_mouse_set_value: app.enzo_midi.cc(app.cc.delay_feedback, self.value)
''')


class EnvTypeSpinner(Spinner):
    def set_knob(self, _, value):
        self.text = self.values[0] if value in range(0, 64) else self.values[1]


class SynthModeSpinner(Spinner):
    def set_knob(self, _, value):
        modes = {0: self.values[0], 63: self.values[1], 95: self.values[2], 127: self.values[3]}
        self.text = modes[value]


class WaveShapeSpinner(Spinner):
    def set_knob(self, _, value):
        self.text = self.values[0] if value == 0x00 else self.values[1]


class FilterTypeSpinner(Spinner):
    def set_knob(self, _, value):
        if value in range(0x00, 0x04):
            self.text = self.values[0]
        elif value in range(0x04, 0x21):
            self.text = self.values[1]
        elif value in range(0x21, 0x3C):
            self.text = self.values[2]
        elif value in range(0x3C, 0x58):
            self.text = self.values[3]
        elif value in range(0x58, 0x74):
            self.text = self.values[4]
        else:
            self.text = self.values[5]


class TempoSlider(Slider):
    def set_knob(self, _, value):
        self.value = -value


polyswell_empty_head = [0] * 7 + [0x01, 0x06, 0x7B, 0x7F, 0x21, 0x7B, 0x39, 0x00, 0x54, 0x7F, 0x00, 0x66, 0x00, 0x7F,
                                  0x00, 0x7F, 0x00, 0x7F, 0x40, 0x7B, 0x7F, 0x21, 0x7B, 0x39, 0x00, 0x54, 0x7F, 0x00,
                                  0x66, 0x00]  # Polyswell with an empty header


class Editor(GridLayout):
    pitch_values = ['-24'] + \
                   ['-12' for _ in range(0x01, 0x0C)] + ['-11' for _ in range(0x0C, 0x10)] + \
                   ['-10' for _ in range(0x10, 0x14)] + ['-9' for _ in range(0x014, 0x18)] + \
                   ['-8' for _ in range(0x18, 0x1C)] + ['-7' for _ in range(0x1c, 0x20)] + \
                   ['-6' for _ in range(0x20, 0x24)] + ['-5' for _ in range(0x24, 0x28)] + \
                   ['-4' for _ in range(0x28, 0x2C)] + ['-3' for _ in range(0x2C, 0x30)] + \
                   ['-2' for _ in range(0x30, 0x34)] + ['-1' for _ in range(0x34, 0x38)] + \
                   ['0' for _ in range(0x38, 0x48)] + ['1' for _ in range(0x48, 0x4C)] + \
                   ['2' for _ in range(0x4C, 0x50)] + ['3' for _ in range(0x50, 0x54)] + \
                   ['4' for _ in range(0x54, 0x58)] + ['5' for _ in range(0x58, 0x5C)] + \
                   ['6' for _ in range(0x5C, 0x60)] + ['7' for _ in range(0x60, 0x64)] + \
                   ['8' for _ in range(0x64, 0x68)] + ['9' for _ in range(0x68, 0x6C)] + \
                   ['10' for _ in range(0x6C, 0x70)] + ['11' for _ in range(0x70, 0x74)] + \
                   ['12' for _ in range(0x74, 0x7F)] + ['24']

    filter_env_values = ['Off'] + ['D' + str(x) for x in range(63, 0, -1)] + ['A' + str(x) for x in range(0, 64)]
    filter_follower_env_values = ['Off'] + [str(x) for x in range(-63, 1)] + ['+' + str(x) for x in range(1, 64)]
    delay_level_values = ['Off'] + ['S' + str(x)for x in range(1, 64)] + ['D' + str(x) for x in range(1, 64)] + ['PP']

    ui = None

    def process_cc(self, cc_knob, value):
        # print(f'In knobs knob:{cc_knob} value:{value}')
        knob_map = {9: self.ids.envelope_type,
                    # 15: self.ids.tempo,  tempo sent from editor is echoed and causes a loop, Enzo sends tap, not tempo
                    16: self.ids.pitch,
                    17: self.ids.filter,
                    18: self.ids.mix,
                    19: self.ids.sustain,
                    20: self.ids.filter_envelope,
                    21: self.ids.modulation,
                    22: self.ids.portamento,
                    23: self.ids.filter_type,
                    24: self.ids.delay_level,
                    25: self.ids.ring_modulation,
                    26: self.ids.filter,            # filter and filter_bandwidth map to the xyknob
                    27: self.ids.delay_feedback,
                    29: self.ids.synth_mode,
                    30: self.ids.synth_waveshape}
        try:
            knob_map[cc_knob].set_knob(cc_knob, value)
        except KeyError:
            pass

    def process_ui(self, patch):
        Editor.ui = patch
        _ = None
        # set the values common to toeup and down

        self.ids.synth_waveshape.set_knob(_, patch[21])
        self.ids.synth_mode.set_knob(_, patch[22])
        self.ids.envelope_type.set_knob(_, patch[23])
        self.ids.tempo.set_knob(_, patch[24])

        # set knobs to reflect the toe position
        offset = 0 if self.ids.toe_up.state == 'normal' else 17
        self.ids.pitch.set_knob(_, patch[8+offset])
        self.ids.filter.set_knob(17, patch[9+offset])  # filter cutoff
        self.ids.mix.set_knob(_, patch[10+offset])
        self.ids.sustain.set_knob(_, patch[11+offset])
        self.ids.filter_envelope.set_knob(_, patch[12+offset])
        self.ids.modulation.set_knob(_, patch[13+offset])
        self.ids.portamento.set_knob(_, patch[14+offset])
        self.ids.filter_type.set_knob(_, patch[15+offset])
        self.ids.delay_level.set_knob(_, patch[16+offset])
        self.ids.ring_modulation.set_knob(_, patch[17+offset])
        self.ids.filter.set_knob(26, patch[18+offset])  # filter_bw, filter and filter_bandwidth map to the xyknob
        self.ids.delay_feedback.set_knob(_, patch[19+offset])

    def read_ui_knobs(self):
        """reads the current values of all of the knobs from the on screen UI, returns a headless patch"""
        hp = [self.ids.pitch.value,
              self.ids.filter.value_x,  # Filter cutoff
              self.ids.mix.value,
              self.ids.sustain.value,
              self.ids.filter_envelope.value,
              self.ids.modulation.value,
              self.ids.portamento.value,
              (0x00, 0x04, 0x21, 0x3C, 0x58, 0x74)[self.ids.filter_type.values.index(self.ids.filter_type.text)],
              self.ids.delay_level.value,
              self.ids.ring_modulation.value,
              self.ids.filter.value_y,  # filter_bw, filter and filter_bandwidth map to the xyknob
              self.ids.delay_feedback.value,
              0x7f,  # Bypass mode
              (0x00, 0x7f)[self.ids.synth_waveshape.values.index(self.ids.synth_waveshape.text)],
              (0, 63, 95, 127)[self.ids.synth_mode.values.index(self.ids.synth_mode.text)],
              (0x00, 0x7f)[self.ids.envelope_type.values.index(self.ids.envelope_type.text)],
              int(self.ids.tempo.value * -1)]
        for i in range(0,12):
            hp.append(hp[i])  # copy all of the toe_up values to toe_down
        return hp

    @staticmethod
    def copy_toe_up_to_down():
        """Copy the toe up to toe down in the cached UI, and send to device, rely on reciving the UI to setknobs"""
        app = App.get_running_app()
        if not app.is_connected and Editor.ui is None:
            Editor.ui = polyswell_empty_head
        patch = list(Editor.ui)
        for i in range(8, 20):
            patch[i+17] = patch[i]
        app = App.get_running_app()
        app.enzo_midi.preview_patch(patch[8:])
        app.enzo_midi.send_command(app.sysex.ui_state_req)

    def set_toe(self, expression_pedal_value):
        app = App.get_running_app()
        app.enzo_midi.cc(app.cc.expression_pedal, expression_pedal_value)
        app.enzo_midi.send_command(app.sysex.ui_state_req)
        if not app.is_connected:
            if Editor.ui is None:
                Editor.ui = polyswell_empty_head
            self.process_ui(Editor.ui)

    def reset_expression_pedal(self):
        """Called when a preset button is pushed to ensure the expression pedal control is reset"""
        app = App.get_running_app()
        if self.ids.toe_up.state == 'down':
            app.enzo_midi.cc(app.cc.expression_pedal, 0)  # set expression pedal to toe up
            self.ids.toe_up.state = 'normal'
            app.enzo_midi.send_command(app.sysex.ui_state_req)
        self.ids.exp_pedal.state = 'normal'


if __name__ == '__main__':
    from enzo_midi import EnzoMidi, CC

    class TestEditApp(App):
        enzo_midi = EnzoMidi()
        cc = CC

        def build(self):
            self.title = 'Enzo Editor & Librarian'
            self.icon = 'Enzo icon.png'
            return Builder.load_string(kv_str + "Editor:\n")

    TestEditApp().run()
