"""Global parameter Editor Screen for Meris Enzo"""

from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.properties import NumericProperty
from kivy.lang import Builder

kv_str = ('''
#: set enzo_orange [251/255, 176/255, 56/255, 1]
#: set white [1, 1, 1, 1]
#: set black [0, 0, 0, 1]

<Globals>:
    cols: 2
    padding: dp(60)
    spacing: dp(50)
    canvas.before:
        Color:
            rgba: enzo_orange
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(20)
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba: black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                markup: True
                text: '[b]Input Mode[/b]'                               
            BoxLayout:
                CheckBox:
                    id:mono
                    group: 'input'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: stereo.active = True 
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.trs_in, app.gv.off) 
                Label:
                    text: 'Mono In'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
            BoxLayout:    
                CheckBox:
                    id:stereo
                    group: 'input'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: mono.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.trs_in, app.gv.on) 
                Label:
                    text: 'Stereo In (TRS)'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]Kill Dry[/b]'
                markup: True                               
            BoxLayout:
                CheckBox:
                    id:dry_active
                    group: 'killdry'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: dry_muted.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.kill_dry, app.gv.off) 
                Label:
                    text: 'Dry Active'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
            BoxLayout:
                CheckBox:
                    id: dry_muted
                    group: 'killdry'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: dry_active.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.kill_dry, app.gv.on)
                Label:
                    text: 'Dry Muted'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
        
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]Line/Synth Level[/b]'
                markup: True                               
            BoxLayout:
                CheckBox:
                    id: instrument_level
                    group: 'level'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: line_level.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.input_level, app.gv.off)
                Label:
                    text: 'Instrument'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black                    
            BoxLayout:
                CheckBox:
                    id: line_level
                    group: 'level'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: instrument_level.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.input_level, app.gv.on)
                Label:
                    text: 'Line'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black    
        
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]Bypass[/b]'
                markup: True                               
            BoxLayout:
                CheckBox:
                    id: buffered_bypass
                    group: 'bypass'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: relay_bypass.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.relay_bypass, app.gv.off)
                Label:
                    text: 'Buffered Bypass'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
            BoxLayout:
                CheckBox:
                    id: relay_bypass
                    group: 'bypass'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: buffered_bypass.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.relay_bypass, app.gv.on)
                Label:
                    text: 'Relay Bypass'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
        
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(20)
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba: black
                Line:
                    width: dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                markup: True
                text: '[b]MIDI Thru On[/b]'                                      
            BoxLayout:
                Label:
                    text: 'Set Enzo to MIDI OUT to use the Editor'
                    text_size: self.size
                    valign: 'middle'
                    halign: 'center'
                    color: black
            Label:
                text:''  
                
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]Global Tempo[/b]'
                markup: True                               
            BoxLayout:
                CheckBox:
                    id: global_tempo
                    group: 'tempo'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: preset_tempo.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.tempo, app.gv.off) 
                Label:
                    text: 'Global Tempo'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
            BoxLayout:
                CheckBox:
                    id: preset_tempo
                    group: 'tempo'
                    color: black
                    size_hint_x: .1
                    on_release: if not self.active: global_tempo.active = True # one option must be selected
                    on_active: if self.active: app.enzo_midi.write_global(app.ga.tempo, app.gv.on)  
                Label:
                    text: 'Tempo Per Preset'
                    text_size: self.size
                    halign: 'left'
                    valign: 'middle'
                    color: black
        
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]MIDI Channel[/b]'
                markup: True                               
            BoxLayout:
                Label:
                    text: 'Set Enzo & Editor to the same MIDI Channel'
                    text_size: self.size
                    valign: 'middle'
                    halign: 'center'
                    color: black
            Label:
                text:''  
        
        BoxLayout:
            orientation:'vertical'
            canvas.after:
                Color:
                    rgba:black
                Line:
                    width:dp(2)
                    rounded_rectangle: (*self.pos,self.width, self.height, 2)
            Label:
                text: '[b]Trails and Split[/b]'
                markup: True 
                size_hint_y: 1/3                              
            BoxLayout:
                orientation: 'horizontal'
                size_hint_y: 2/3
                BoxLayout:
                    orientation: 'vertical'
                    BoxLayout:
                        Label:
                            text:''
                            size_hint_x: .1
                        Label:
                            text: 'Trails are ' + ('OFF' if root.ts_state in [0] else 'ON')
                            # Errata in Enzo, if split is on trails are on 
                            text_size: self.size
                            valign: 'middle'
                            color: black
                    BoxLayout:
                        Label:
                            text:''
                            size_hint_x: .1
                        Label:
                            text: 'Split is ' + ('OFF' if root.ts_state in [0, 2] else 'ON')
                            text_size: self.size
                            valign: 'middle'
                            color: black
                BoxLayout:
                    padding: [dp(0), dp(0), dp(4), dp(4)]
                    orientation: 'vertical'
                    Label:
                        text: 'Must be set on the Enzo,\\nif Split is ON, Trails are ON'
                        color: black
                    Button:
                        text: 'Turn Both OFF'
                        on_release: root.ts_state = 0; app.enzo_midi.write_global(app.ga.trails, app.gv.off)  
''')


class Globals(GridLayout):
    ts_state = NumericProperty(1)

    def process_globals(self, g_state):
        """When Global State is received, this method sets all values"""
        self.ids.stereo.active = g_state[10] == 0x7F
        self.ids.mono.active = not self.ids.stereo.active  # g_state[10] == 0x00

        self.ids.instrument_level.active = g_state[11] == 0x00
        self.ids.line_level.active = not self.ids.instrument_level.active

        self.ids.buffered_bypass.active = g_state[12] == 0x00
        self.ids.relay_bypass.active = not self.ids.buffered_bypass.active

        self.ids.dry_active.active = g_state[13] == 0x00
        self.ids.dry_muted.active = not self.ids.dry_active.active

        self.ts_state = g_state[15]

        self.ids.global_tempo.active = g_state[16] == 0x00
        self.ids.preset_tempo.active = not self.ids.global_tempo.active


if __name__ == '__main__':
    class TestGlobalsApp(App):

        def build(self):
            self.title = 'Enzo Global Editor'
            self.icon = 'enzo.png'
            return Builder.load_string(kv_str + "Globals:\n")


    TestGlobalsApp().run()
