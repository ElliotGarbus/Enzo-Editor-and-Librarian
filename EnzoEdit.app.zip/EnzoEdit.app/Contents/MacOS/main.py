import configstartup
import re
import json
import kivy
from pathlib                import PurePath
from kivy.app               import App
from kivy.uix.boxlayout     import BoxLayout
from kivy.uix.gridlayout    import GridLayout
from kivy.uix.scrollview    import ScrollView
from kivy.uix.widget        import Widget
from kivy.uix.togglebutton  import ToggleButton
from kivy.uix.button        import Button
from kivy.uix.label         import Label
from kivy.uix.popup         import Popup
from kivy.lang              import Builder
from kivy.uix.screenmanager import ScreenManager, Screen, WipeTransition
from kivy.properties        import StringProperty,NumericProperty, BooleanProperty
from kivy.uix.behaviors     import DragBehavior
from kivy.graphics          import Color, Rectangle
from kivy.uix.behaviors     import ButtonBehavior
from kivy.uix.image         import Image
from kivy.clock             import Clock
from kivy.uix.settings      import SettingsWithNoMenu, SettingOptions, SettingSpacer
from kivy.core.window       import Window
from kivy.metrics           import dp, Metrics

from enzo_midi              import SYSEX, GlobalAdr, GlobalVal, CC
from enzo_midi              import EnzoMidi, ConnectMidiPopup, midi_dialog
from Patches                import Patches
from thelibrary             import Thelibrary
import edit
import enzo_globals
import patch_save
import genpan

kivy.require('1.10.1')

kivy_string = '''
#: import json json
#: import Factory kivy.factory.Factory
#: import Clock kivy.clock
#: import webbrowser webbrowser
#: import WipeTransition kivy.uix.screenmanager 
#: set red [1, 0, 0, 1]
#: set green [0, 1, 0, 1]
#: set paypal_site 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7JWFZQUM4CJRJ&source=url'
#from boxlayout
MainScreen:
    orientation: 'vertical'
    ActionBar:
        pos_hint: {'top':1}
        ActionView:
            ActionPrevious:
                title: "Editor & Librarian"
                app_icon: 'enzo e.png'
                with_previous: 'editor' != root.ids.sm.current
                on_press:
                    root.ids.sm.current = 'editor' if 'editor' != root.ids.sm.current else 'librarian'
                    root.ids.sm.transition.direction = 'left' if 'editor' != root.ids.sm.current else 'right'
            ActionButton:
                text: 'Editor'
                on_press:
                    root.ids.sm.current = 'editor'
                    root.ids.sm.transition.direction = 'right'
            ActionButton:
                text: 'Librarian'
                # color: 1,.2,1,1
                on_press:
                    root.ids.sm.current = 'librarian'
                    root.ids.sm.transition.direction = 'left'
            ActionButton:
                text: 'Generator'
                on_press:
                    app.toggle_gen_pan()
            ActionSeparator:  
            ActionButton:
                text: 'Connect' if not app.is_connected else 'Connected'
                color: green if app.is_connected else red
                on_release: app.open_midi_dialog()
            ActionSeparator:    
            ActionGroup:
                mode: "spinner"
                text: 'Preset Group'     
                ActionButton:
                    text: 'Load'
                    on_release:
                        Factory.GrpFilePopup().open()
                ActionButton:
                    text: 'Save'
                    on_release:
                        Factory.GrpFileSvPopup().open()
            ActionButton:
                # color: (1,0,0,1)
                text: 'Save to Enzo & Lib' 
                on_release: app.schedule_save_patch()
                disabled: not app.is_connected
            ActionButton:
                text: 'Import'
                on_release:
                    app.filefilter = ['*.json', '*.syx']
                    Factory.FilePopup().open()
            ActionGroup:
                mode: "spinner"
                text: 'Settings'     
                ActionButton:
                    text: 'Enzo Globals'
                    on_press:
                        root.ids.sm.current = 'globals'
                        root.ids.sm.transition.direction = 'down'
                ActionButton:
                    text: 'App Settings'
                    on_release:
                        app.open_settings()
                        root.ids.sm.transition.direction = 'up'
                        root.ids.sm.current = 'config'  
            ActionGroup:
                mode: "spinner"
                text: 'Help'
                ActionButton:
                    text: "Intro Video"
                    #on_release: webbrowser.open('https://youtu.be/AEB-HyNV6LU') # TODO: replace with how to use app video
                    on_release: webbrowser.open( app.config.get('Enzo', 'intro_vid_url' ) )
                ActionButton:
                    text: "Enzo Manual"
                    #on_release: webbrowser.open('https://www.meris.us/wp-content/uploads/2018/06/Meris_Enzo_Manual_v1c.pdf')
                    on_release: webbrowser.open( app.config.get('Enzo', 'man_url' ) )
                ActionButton:
                    text: 'Donate'
                    on_release: webbrowser.open(paypal_site)
                ActionButton:
                    text: "About"
                    on_release: Factory.AboutPopup().open()
    BoxLayout:
        orientation: 'horizontal'
        id: under_action
        BoxLayout:
            size_hint_x: .15
            orientation: 'vertical'
            spacing: dp(2)
            padding: dp(2)
            Label:
                text: 'Presets'
                font_size: '25sp'
                color: enzo_orange
                #color: 1, .1, .2, 1
            Prebut:
                id:preset_button_1
                preset: 1
            Prebut:
                preset: 2
            Prebut:
                preset: 3
            Prebut:
                preset: 4
            Prebut:
                preset: 5
            Prebut:
                preset: 6
            Prebut:
                preset: 7
            Prebut:
                preset: 8
            Prebut:
                preset: 9
            Prebut:
                preset: 10
            Prebut:
                preset: 11
            Prebut:
                preset: 12
            Prebut:
                preset: 13
            Prebut:
                preset: 14
            Prebut:
                preset: 15
            Prebut:
                preset: 16
        
        ScreenManager:
            id: sm
            Screen_editor:
                name: 'editor'
            Screen_librarian:
                name: 'librarian'
            Screen_globals:
                name: 'globals'
            Screen_config:
                name: 'config'
        Label:
            id: track2
            opacity: 0
            size_hint: None,None
            valign:'middle'
            size: 0,0
            color: 1, 1, 1, 1
            canvas:
                Color:
                    rgba: 0, 0, 0, 0.4
                Rectangle: 
                    pos:(self.x-preset_button_1.width*.5, self.y-preset_button_1.height*.5)
                    size: preset_button_1.size

# from button
<Prebut>:
    text: '  ' + str(self.preset) + ' ' + self.patchname
    halign: 'left'
    valign: 'center'
    text_size: self.size

<Screen_config@Screen>:
    BoxLayout:
        id: config_attach
        padding: dp(10)
        orientation: 'vertical'

<Screen_globals@Screen>:
    on_pre_enter: app.enzo_midi.send_command(app.sysex.globals_req) 
    Globals:
        id: enzo_globals

<Screen_editor@Screen>:
    Editor:
        id: editor

<Screen_librarian@Screen>:
    canvas.before:
        Color:
            rgba: enzo_orange
        Rectangle:
            size: self.size
    BoxLayout:
        padding: dp(6)
        spacing: dp(4)
        orientation: 'vertical'
        BoxLayout:
            orientation: 'vertical'
            id: attach
            BoxLayout:
                height: dp(30)
                padding: dp(4)
                spacing: dp(2)
                size_hint_y: None
                orientation: 'horizontal'
                Label:
                    id: name_field
                    size_hint_x: .2
                    font_size: fs
                    text_size: self.size
                    halign: 'left'
                    valign: 'center'
                    text: 'Name'
                Label:
                    text: 'Description'
                    font_size: fs
                    text_size: self.size
                    halign: 'left'
                    valign: 'center'
        BoxLayout:
            size_hint_y: None
            height: dp(46)
            canvas.before:
                Color:
                    rgba: black
                Rectangle:
                    size: self.size
            TextInput:
                id: search_box
                on_text: app.mylib.rename_lib()
                text: ''
                hint_text: 'Search'
                size_hint: (None,None)
                #size: (100,30)
                height: dp(30)
                width: name_field.width
                #pos_hint: { 'center_y':.5 }
            Label:
                size_hint_x: None
                width: dp(30)
            IconButton:
                id: save_icon
                source: 'save.png'
                size_hint: (None,None)
                size: (dp(38),dp(38))
                on_release:
                    app.filefilter = ['*.json']
                    Factory.FilePopup().open()
            Label:
                size_hint_x: None
                width: dp(30)
            IconButton:
                id: sysx_icon
                source: 'SYX.png'
                size_hint: (None,None)
                size: (dp(45),dp(45))
                on_release:
                    app.filefilter = ['*.syx']
                    Factory.FilePopup().open()
            Label:
            Image:
                id: trash
                source: 'trash.png'
                size_hint: (None,None)
                size: (dp(38),dp(38))
            Label:
                size_hint_x: None
                width: dp(10)

<FilePopup@Popup>:
    title: 'Select a file to load into the library'
    size_hint: .6,.75
    BoxLayout:
        orientation: 'vertical'
        FileChooserListView:
            id: filechooser
            filters: app.filefilter
            path: app.config.get('Enzo', 'default_dir' )
        Label:
            size_hint_y: .08
            text: 'File Selected: ' + app.just_fname(filechooser.selection)
        BoxLayout:
            size_hint_y: .1
            orientation: 'horizontal'
            Button:
                id: filebut
                text: 'Open'
                disabled: 0==len( filechooser.selection )
                on_release:
                    app.mylib.loadfiles( filechooser.selection )
                    root.dismiss()
            Button:
                text: 'Cancel'
                on_release: root.dismiss()

<GrpFilePopup@Popup>:
    title: 'Select a preset group file to load onto the preset buttons'
    size_hint: .6,.75
    BoxLayout:
        orientation: 'vertical'
        FileChooserListView:
            id: filechooser
            filters: ['*.pgr']
            path: app.config.get('Enzo', 'lib_dir' )
        Label:
            size_hint_y: .08
            text: 'File Selected: ' + app.just_fname(filechooser.selection)
        BoxLayout:
            size_hint_y: .1
            orientation: 'horizontal'
            Button:
                id: filebut
                text: 'Load'
                disabled: 0==len( filechooser.selection )
                on_release:
                    app.load_presets( filechooser.selection[0] )
                    root.dismiss()
            Button:
                text: 'Cancel'
                on_release: root.dismiss()

<GrpFileSvPopup@Popup>:
    title: 'Save the 16 preset buttons to a preset group file'
    size_hint: .6,.75
    BoxLayout:
        orientation: 'vertical'
        FileChooserListView:
            id: filechooser
            filters: ['*.pgr']
            path: app.config.get('Enzo', 'lib_dir' )
            on_selection: text_input.text =  self.selection and self.selection[0] or ''
        Label:
            size_hint_y: .08
            text: 'File Selected: ' + app.just_fname(filechooser.selection)
        TextInput:
            size_hint_y: .1
            id: text_input
        BoxLayout:
            size_hint_y: .1
            orientation: 'horizontal'
            Button:
                id: filebut
                text: 'Save'
                #disabled: 0==len( filechooser.selection )
                on_release:
                    app.save_presets( text_input.text, filechooser.path  )
                    root.dismiss()
            Button:
                text: 'Cancel'
                on_release: root.dismiss()



<ErrPopup>:
    title: 'Error'
    size_hint: (.5,.5)
    BoxLayout:
        orientation: 'vertical'
        Label:
            id: message
            text_size: self.size
            valign: 'middle'
        Button:
            size_hint_y: None
            height: dp(30)
            text: 'Close'
            on_release: root.dismiss()
<Liblin>:
    size_hint_y: None
    height: dp(30)
    orientation: 'horizontal'
    Button:
        id: entry_name
        size_hint_x: .2
        text: root.myname
        text_size: self.size
        halign: 'left'
        valign: 'center'
        on_press:   app.trk_start(self)
        on_release: app.trk_end  (self)
    TextInput:
        text: root.mydesc
        id: entry_description
        multiline: False
        on_text:
            app.mylib.update_entry_description(root.ids.entry_name.text,self.text)
        text_size: self.size
        halign: 'left'
        valign: 'center'
<AboutPopup@Popup>:
    title: 'Enzo Editor and Librarian ' + app.version
    size_hint: (.5,.9)
    BoxLayout:
        orientation: 'vertical'
        Label:
            text_size: self.size
            valign: 'middle'
            text: app.about
        Button:
            size_hint_y:.20
            text:'Donate'
            on_release: webbrowser.open(paypal_site)
        Button:
            size_hint_y:.20
            text: 'Close'
            on_release: root.dismiss()
'''

jsonsettings = '''
[
    {
        "type": "title",
        "title": "Setup Parameters"
    },
    {
        "type": "path",
        "title": "Default directory to Open/Save Patches",
        "desc": "Directory location to import or export patch files",
        "section": "Enzo",
        "key": "default_dir"
    },
    {
        "type": "path",
        "title": "Default directory for library",
        "desc": "Directory location for the library",
        "section": "Enzo",
        "key": "lib_dir"
    },
    {
        "type": "string",
        "title": "URL for Enzo Manual",
        "desc": "Change if the URL for the Enzo Manual is updated",
        "section": "Enzo",
        "key": "man_url"
    },
    {
        "type": "string",
        "title": "URL for the Enzo Intro video",
        "desc": "Change if the URL for the Enzo Intro video is updated",
        "section": "Enzo",
        "key": "intro_vid_url"
    }
]
'''


class ErrPopup(Popup):
    pass


class IconButton(ButtonBehavior, Image):
    pass

#Preset buttons are special (they can be identified)


class Prebut(Button):
    preset = NumericProperty(1)
    patchname = StringProperty('Unnamed')

    def on_release(self):
        # Presets 1-16; Preset 0 is bypass
        MainApp.enzo_midi.pc(self.preset)
        # print('DEBUG: sent a program change (with pc()) to preset', self.preset )
        app = App.get_running_app()
        app.root.ids.sm.get_screen('editor').ids.editor.reset_expression_pedal()
        if not app.is_connected and self.patchname != 'Unnamed':
            app.enzo_midi.preview_patch(app.mylib.get_headless_patch(self.patchname))


class MainScreen(BoxLayout):
    def on_touch_move(self,touch):
        app_ptr = App.get_running_app()
        if app_ptr.trklab.opacity:
            app_ptr.trklab.center  = touch.pos 
            return True
        return False

    def on_touch_up(self,touch):
        app_ptr = App.get_running_app()
        em = MainApp.enzo_midi

        if app_ptr.trklab.opacity:
            app_ptr.trklab.opacity = 0

            for c in app_ptr.mylib.prebut_list():
                if hasattr(c,'preset') and c.collide_point(*touch.pos):
                    c.patchname = app_ptr.trklab.text    # change button name
                    bstr  = (app_ptr.mylib.get_headless_patch(app_ptr.trklab.text))
                    em.write_patch( c.preset, bstr )
                    # print('DEBUG: lib entry', app_ptr.trklab.text, 'sent to preset',c.patchname, ' with write_patch()', bstr )
                    return

            trash   = app_ptr.root.ids.sm.get_screen('librarian').ids.trash
            savefl  = app_ptr.root.ids.sm.get_screen('librarian').ids.save_icon
            savesyx = app_ptr.root.ids.sm.get_screen('librarian').ids.sysx_icon

            ddir    = app_ptr.config.get('Enzo', 'default_dir' ) + '/'

            if trash.collide_point(*trash.to_widget(*touch.pos,relative=False)):
                app_ptr.mylib.delete_entry( app_ptr.trklab.text )

            if savefl.collide_point(*savefl.to_widget(*touch.pos,relative=False)):
                # print( 'write json file ', ddir + app_ptr.trklab.text )
                json.dump( { app_ptr.trklab.text : app_ptr.mylib.thelib[ app_ptr.trklab.text ]},
                          open(ddir + app_ptr.trklab.text + '.json','w'),
                          indent=2 )
            if savesyx.collide_point(*savesyx.to_widget(*touch.pos,relative=False)):
                # print( 'write to sysx file ', ddir + app_ptr.trklab.text )
                open(ddir + app_ptr.trklab.text + '.syx', 'wb').write(
                    bytearray(
                        [ 0xf0, 0, 32, 16, 0, 1, 3 , 38, 1]
                      + app_ptr.mylib.get_headless_patch(app_ptr.trklab.text)
                      + [ 0xf7 ] ) )
            # if genpan is open, then check if we dropped over there...
            if app_ptr.gen_widget is not None:
                genpan.do_drag_drops(touch)
            return True
        return False

about_message = """
Developed by Elliot Garbus and Seth Abraham

The Enzo Editor and Librarian is NOT a product of Meris, LLC.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE \
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR \
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR \
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

If your're using this software please consider supporting our efforts by making a donation.  Thanks!
"""

class MainApp(App):
    is_connected = BooleanProperty(False)
    version = 'Version 2.0'
    about = about_message
    enzo_midi = EnzoMidi()
    mylib     = Thelibrary()
    cc        = CC
    sysex     = SYSEX
    ga        = GlobalAdr
    gv        = GlobalVal
    gen_widget= None

    def toggle_gen_pan(self):
        if (self.gen_widget is None):
            self.gen_widget = genpan.Genpan()     # replace me with imported panel class call
            self.root.ids.under_action.add_widget( self.gen_widget, index=2 )
        else:
            self.root.ids.under_action.remove_widget( self.gen_widget )
            self.gen_widget = None

    def just_fname(self, namelst):
        sname = '<none>'
        if len(namelst) > 0:
            name  = namelst[0]
            sname = re.sub('.*/', '',name)      # strip down file name (linux)
            sname = re.sub(r'.*\\', '', sname)  # strip down file name (win)
        return sname

    def trk_start(self,libbut):
        self.trklab.center   = libbut.to_window(*libbut.center)
        self.trklab.text     = libbut.text
        self.trklab.opacity  = 1
        return True

    #called only when trk lable did not move at all
    # (entry point for select operation????)
    def trk_end(self,libbut):
        em = MainApp.enzo_midi

        self.trklab.opacity  = 0

        bstr  = self.mylib.get_headless_patch(self.trklab.text)
        em.preview_patch( bstr )

        # print('DEBUG: lib entry', self.trklab.text,'sent to Enzo device with preview_patch()', bstr )

        return True

    def open_midi_dialog(self):
        midi_dialog()

    def test_midi_connection(self, dt):
        """Test if the midi port has been disconnected"""
        em = MainApp.enzo_midi
        if em.midi_channel != 'None' and not em.is_port_connected():
            self.is_connected = False
            em.to_enzo = None
            em.from_enzo = None


    def schedule_save_patch(self):
        self.enzo_midi.send_command(SYSEX.ui_state_req)
        Clock.schedule_once(self.patch_save, 0.25)

    def patch_save(self, dt):
        p = edit.Editor.ui
        if p[8:] in self.mylib:  # p[8:] is a headless patch (header stripped off)
            name = self.mylib.get_name_of(p[8:])
            self.error_popup.ids.message.text = 'This sound is in the Library as: ' + name
            self.error_popup.open()
        else:
            ps = patch_save.PatchSavePopup()
            ps.headless_patch = p[8:]
            ps.open()

    def build_config(self, config):
        config.setdefaults('MIDI', {'input': 'None',
                                    'output': 'None',
                                    'channel': 'None'})
        config.setdefaults('Enzo', {'lib_dir': '.',
                                    'default_dir': '.',
                                    'man_url': 'https://www.meris.us/wp-content/uploads/2018/06/Meris_Enzo_Manual_v1c.pdf',
                                    'intro_vid_url': 'https://youtu.be/AEB-HyNV6LU' })
        config.setdefaults('Window', {'width': configstartup.window_width,
                                      'height': configstartup.window_height})
        config.setdefaults('Window', {'top': configstartup.window_top,
                                      'left': configstartup.window_left})


    def build_settings(self,settings):
        settings.add_json_panel('Enzo', self.config, data=jsonsettings)

    def display_settings(self,settings):
        r = App.get_running_app().root
        if settings not in r.ids.sm.get_screen('config').ids.config_attach.children:
            r.ids.sm.get_screen('config').ids.config_attach.add_widget( settings  )
        return True

    def on_config_change(self, config, section, key, value):
        pass

    def build(self):
        # em = MainApp.enzo_midi
        Builder.load_string( edit.kv_str )
        Builder.load_string(enzo_globals.kv_str)
        r = Builder.load_string(kivy_string)
        self.title = 'Enzo Editor & Librarian'
        self.icon = 'enzo e.png'
        Window.minimum_width = configstartup.window_width
        Window.minimum_height = configstartup.window_height

        self.settings_cls = SettingsWithNoMenu
        self.use_kivy_settings = False

        self.mylib.read_database(r) 
        self.trklab      = r.ids.track2
        self.error_popup = ErrPopup()
        Window.bind(on_request_close=self.window_request_close)
        return r

    def window_request_close(self, win):
        # Window.size is automatically adjusted for density, must divide by density when saving size
        config = self.config
        config.set('Window', 'width', int(Window.size[0]/Metrics.density))
        config.set('Window', 'height', int(Window.size[1]/Metrics.density))
        config.set('Window', 'top', Window.top)
        config.set('Window', 'left', Window.left)
        return False


    def on_start(self):
        # Set Window to previous size and position
        config = self.config
        width =  config.getdefault('Window', 'width', configstartup.window_width)
        height = config.getdefault('Window', 'height', configstartup.window_height)
        Window.size = (int(width), int(height))
        Window.top = int(float(config.getdefault('Window', 'top', configstartup.window_top)))
        Window.left = int(float(config.getdefault('Window', 'left', configstartup.window_left)))

        #  Set up the midi recieve routine and call back
        em = MainApp.enzo_midi
        midi_ch = config.getdefault('MIDI', 'channel', 'None')
        midi_in = config.get('MIDI', 'input')
        midi_out = config.get('MIDI', 'output')
        em.get_midi_ports()
        if midi_ch != 'None' and midi_in in em.midi_in_names and midi_out in em.midi_out_names:
            em.set_midi(midi_ch, midi_in, midi_out)

        Clock.schedule_interval(em.read_midi_callback, .100)  # read the midi port at a regular interval
        Clock.schedule_interval(em.xmit_midi_callback, .150)
        Clock.schedule_interval(self.test_midi_connection, 4)

    def on_stop(self):
        self.mylib.write_database()
        em = MainApp.enzo_midi
        config = self.config
        # config.set('Window', 'width', Window.size[0])
        # config.set('Window', 'height', Window.size[1])
        # config.set('Window', 'top', self.win_top)
        # config.set('Window', 'left', self.win_left)
        if em.to_enzo:
            config.set('MIDI', 'channel', str(em.midi_channel+1))
            config.set('MIDI','input', em.midi_input)
            config.set('MIDI','output', em.midi_output)
        else:
            config.set('MIDI', 'channel', 'None')
            config.set('MIDI', 'input', 'None')
            config.set('MIDI', 'output', 'None')
        config.write()

    def load_presets( self, fname ):
        try:
            pst = json.load(open(fname,'r'))
            pst.insert(0,' ')            # fix list so it indexes 1 to 16, insert a dummy 0
            app_ptr = self
            em      = MainApp.enzo_midi
            #
            # for all buttons, is the loaded list entry in the library?
            #
            for c in app_ptr.mylib.prebut_list():
                if pst[ c.preset ] in app_ptr.mylib:
                    bstr  = app_ptr.mylib.get_headless_patch( pst[ c.preset ] ) 
                    em.write_patch( c.preset, bstr )
                    em.send_command( SYSEX.patch_req )   # request the preset so the name will get updated
                    #print('DEBUG: lib entry', pst[ c.preset ], 'sent to preset',c.preset, ' with write_patch()', bstr )
        except:
            self.error_popup.ids.message.text = 'Load operation failed-- read file failed, or file corrupt'
            self.error_popup.open()

    def save_presets( self, fname, pth ):
        pfname = PurePath(fname)
        if not pfname.is_absolute():
            pfname = PurePath(pth) / pfname
        pfname = pfname.with_suffix('.pgr')
        fname  = str(pfname)
        try:
            json.dump(
                     [{_.preset :_.patchname for _ in self.mylib.prebut_list()}[ i ] for i in range(1,17) ],
                     open(fname,'w'))
        except:
            self.error_popup.ids.message.text = 'Save operation failed'
            self.error_popup.open()


if __name__ == '__main__':
    MainApp().run()

