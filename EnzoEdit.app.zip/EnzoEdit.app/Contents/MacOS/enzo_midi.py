import mido
import mido.backends.rtmidi  # required for pyinstaller to create an exe
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty
from kivy.clock import Clock
from kivy.logger import Logger
from enum import Enum
from collections import namedtuple, deque

Builder.load_string('''
<ConnectMidiPopup>:
    title:'Select MIDI Ports and Channel'
    size_hint: .8,.75
    auto_dismiss: False
    BoxLayout:
        orientation:'vertical'
        Label:
            text:'Select the MIDI Ports & MIDI Channel to connect to ENZO'
            font_size: '25sp'
            size_hint_y:.3
        Label:
            text: root.directions
        BoxLayout:
            size_hint_y: 0.5
            BoxLayout:      
                orientation: 'vertical'
                Label:
                    text: 'MIDI Input'
                Spinner:
                    id: midi_in
            BoxLayout:      
                orientation: 'vertical'
                Label:
                    text: 'MIDI Output'
                Spinner:
                    id:midi_out
            BoxLayout:     
                orientation: 'vertical'
                Label:
                    text: 'MIDI Channel'
                Spinner:
                    id: midi_ch
                    values: ['None'] + [str(x) for x in range(1,17)]
        BoxLayout:
            size_hint_y: 0.2
            Label:
                text:''    
        BoxLayout:
            size_hint_y: 0.25
            Button:
                text: 'Connect'
                on_release: root.connect_to_midi()
            Button:
                text: 'Scan'
                on_release: root.scan_midi_ports()
            Button:
                text:'Cancel'
                on_release: root.dismiss()
                
<LoadPresetsPopup>:
    title:'Reading Presets from the Enzo'
    size_hint: .5,.25
    auto_dismiss: True
    BoxLayout:
        orientation: 'vertical'
        Label:
            text: 'Reading Presets, Writing Names'
            font_size: '25sp'
            text_size: self.size
            valign: 'bottom'
            halign: 'center'
        ProgressBar:
            id: pb_status
            max: 16
            value: 0
        ''')


class SYSEX(Enum):
    ui_state_req = 0x23
    ui_state_recv = 0x24
    patch_req = 0x25
    patch_send = 0x26
    patch_write = 0x29
    globals_req = 0x27
    globals_recv = 0x28
    globals_write = 0x2A


class GlobalAdr(Enum):
    trs_in = 0
    input_level = 1
    relay_bypass = 2
    kill_dry = 3
    trails = 4  # There is an erratta on the Enzo, do not use this command
    tempo = 5


class GlobalVal(Enum):
    off = 0x00
    on = 0x7F


class CC(Enum):
    expression_pedal = 4
    envelope_type = 9
    bypass = 14
    tempo = 15
    pitch = 16
    filter = 17
    mix = 18
    sustain = 19
    filter_env = 20
    modulation = 21
    portamento = 22
    filter_type = 23
    delay_level = 24
    ring_mod = 25
    filter_bw = 26
    delay_feedback = 27
    tap = 28
    synth_mode = 29
    synth_waveshape = 30


Header = namedtuple('Header', ['h' + str(i) for i in range(0,6)] + ['cmd'])
Patch = namedtuple('Patch', ['h0', 'h1', 'h2', 'pid','gid', 'model', 'cmd', 'preset', 'pitch_u', 'filter_u', 'mix_u',
                             'sustain_u', 'filter_env_u', 'modulation_u', 'portamento_u', 'filter_type_u',
                             'delay_level_u', 'ring_mod_u', 'filter_bw_u', 'delay_feedback_u', 'reserved', 'wave_shape',
                             'synth_mode', 'env_type', 'tempo', 'pitch_d', 'filter_d', 'mix_d', 'sustain_d',
                             'filter_env_d', 'modulation_d', 'portamento_d', 'filter_type_d','delay_level_d',
                             'ring_mod_d', 'filter_bw_d', 'delay_feedback_d'])


class EnzoMidi:
    def __init__(self):
        self.midi_channel = 'None'  # holds value of midi channel 0 - 15
        self.midi_input = None    # name of the midi input port
        self.midi_output = None
        self.midi_in_names = None # names of all of the midi input ports
        self.midi_out_names = None
        self.to_enzo = None       # the midi output port
        self.from_enzo = None
        self.startup = True       # used to indicate startup on, controls response to recvd data see: read_midi_callback()
        self.cc_xmit_flag = False # used to suppress responses to cc messages sent from the editor see: read_midi_callback() and  xmit_midi_callback()
        self.midi_xmit_queue = deque()
        self.tap_callback = Clock.schedule_once(self.req_ui_callback, 1)

    def get_midi_ports(self):
        try:
            self.midi_in_names = mido.get_input_names()
            self.midi_out_names = mido.get_output_names()
        except:
            self.midi_in_names = None
            self.midi_out_names = None

    def is_port_connected(self):
        # print(f'is_port_connected: {self.midi_input in mido.get_input_names()}')
        try:
            return self.midi_input in mido.get_input_names()
        except:
            return False

    def set_midi(self, channel: str, input_port: str, output_port: str):
        """Set up midi ports and channel, issue commands to get initial data from the Enzo"""
        self.midi_input = input_port
        self.midi_output = output_port
        if channel == 'None':  # if channel in 'None', close open ports
            self.midi_channel = channel
            if self.to_enzo:
                self.to_enzo.close()
            if self.from_enzo:
                self.from_enzo.close()
            self.to_enzo = None
            self.from_enzo = None
            app = App.get_running_app()
            app.is_connected = False
        else:
            if self.to_enzo:
                self.to_enzo.close()
            if self.from_enzo:
                self.from_enzo.close()
            try:
                self.from_enzo = mido.open_input(input_port)
                self.to_enzo = mido.open_output(output_port)
                self.midi_channel = int(channel) - 1
                self.startup = True             # use startup to suppress UI_req on recv'd PC during startup
                self.lppup = LoadPresetsPopup()
                self.lppup.open()
                for preset_num in range(1,17):
                    self.pc(preset_num)
                    self.send_command(SYSEX.patch_req)
                # startup complete, start up flag gets cleared in read_midi_callback
                self.pc(1)
            except OSError:
                pass

    def send_command(self, command: SYSEX):
        if self.to_enzo:
            enzo_msg = [0x00, 0x20, 0x10, self.midi_channel, 0x01, 0x03, command.value]
            mmsg = mido.Message('sysex', data=enzo_msg)
            self.midi_xmit_queue.append(mmsg)

    def tap(self) -> None:  # Tap bypasses the xmit queue to provide finer gain cotrol of tempo
        if self.to_enzo:
            mmsg = mido.Message('control_change', channel=self.midi_channel, control=CC.tap.value, value=127)
            self.to_enzo.send(mmsg)

    def pc(self, preset: int):
        if self.to_enzo:
            mmsg = mido.Message('program_change', channel=self.midi_channel, program=preset)
            self.midi_xmit_queue.append(mmsg)

    def cc(self, cntrl: CC, value: int) -> None:
        if self.to_enzo:
            mmsg = mido.Message('control_change', channel=self.midi_channel, control=cntrl.value, value=value)
            self.midi_xmit_queue.append(mmsg)

    def write_global(self, gadr: GlobalAdr, value: GlobalVal):
        if self.to_enzo:
            enzo_msg = [0x00, 0x20, 0x10, self.midi_channel, 0x01, 0x03, SYSEX.globals_write.value, gadr.value, value.value]
            mmsg = mido.Message('sysex', data=enzo_msg)
            self.midi_xmit_queue.append(mmsg)

    def preview_patch(self, headless_patch: list) -> None:
        #  patch is a list of the bytes in the patch, it does not include the header or trailing F7 bytes
        #  this command is for use by the librarian
        if self.to_enzo:
            enzo_msg = [0x00, 0x20, 0x10, self.midi_channel, 0x01, 0x03, SYSEX.patch_send.value, 0x00] + headless_patch
            mmsg = mido.Message('sysex', data=enzo_msg)
            self.midi_xmit_queue.append(mmsg)
            self.send_command(SYSEX.ui_state_req)
        else:  # if no midi connection, use preview to get info onto the knobs...
            app = App.get_running_app()
            app.root.ids.sm.get_screen('editor').ids.editor.process_ui([0]*8 + headless_patch)


    def write_patch(self, preset: int, headless_patch: list) -> None:
        #  this command is for use by the librarian it is a composite of other commands
        self.pc(preset)
        if self.to_enzo: # preview the patch, without requesting the UI, the PC will cause a UI request
            enzo_msg = [0x00, 0x20, 0x10, self.midi_channel, 0x01, 0x03, SYSEX.patch_send.value, 0x00] + headless_patch
            mmsg = mido.Message('sysex', data=enzo_msg)
            self.midi_xmit_queue.append(mmsg)
        self.send_command(SYSEX.patch_write)

    def req_ui_callback(self, dt):
        # print(f'Request UI Callback dt: {dt}')
        self.send_command(SYSEX.ui_state_req)

    def xmit_midi_callback(self, dt):
        """Called by the clock function at a schedule interval to xmit MIDI messages, sets cc_xmit_flag"""
        if self.midi_xmit_queue:
            # print(f'Length of the xmit queue:{len(self.midi_xmit_queue)}')
            if not self.midi_xmit_queue[0].type == 'control_change': # not knob data...
                t = self.midi_xmit_queue.popleft()
            else: # knob data, filter the data...
                control = self.midi_xmit_queue[0].control
                self.cc_xmit_flag = True
                if control == 17 or control == 26:  # xy knob
                    # print('xy knob')
                    t17 = None
                    t26 = None
                    while (self.midi_xmit_queue and self.midi_xmit_queue[0].type == 'control_change' and
                           (self.midi_xmit_queue[0].control == 17 or self.midi_xmit_queue[0].control == 26)):
                        if self.midi_xmit_queue[0].control == 17:
                            # print(f'poping knob data: {self.midi_xmit_queue[0]}')
                            t17 = self.midi_xmit_queue.popleft()
                        else:
                            # print(f'poping knob data: {self.midi_xmit_queue[0]}')
                            t26 = self.midi_xmit_queue.popleft()
                    # all 17 and 26 are off the queue, we have the last values if they were on the queue...
                    if t26 and not t17:
                        t = t26
                    else:
                        t = t17
                        if t26:
                            self.midi_xmit_queue.appendleft(t26) # push for next time
                else:
                    while (self.midi_xmit_queue and self.midi_xmit_queue[0].type == 'control_change' and
                        self.midi_xmit_queue[0].control == control):
                        # print(f'poping knob data: {self.midi_xmit_queue[0]}')
                        t = self.midi_xmit_queue.popleft()
            # print(f'xmit: {t}')
            self.to_enzo.send(t)

    def read_midi_callback(self, dt):
        """Called by the clock function at a scheduled interval to read midi messages"""
        if self.from_enzo:
            app = App.get_running_app()
            for msg in self.from_enzo.iter_pending():
                if msg.type =='control_change' and msg.channel == self.midi_channel:
                    # print('CC Message Received')
                    # print(f'cc:ch{msg.channel}, control:{msg.control}, value:{msg.value}')
                    if msg.control == CC.tap.value: # if tap, get the UI to read the new tempo
                        # self.send_command(SYSEX.ui_state_req)
                        self.tap_callback() # don't call ui for every tap if they are fast.
                    else:
                        if not self.cc_xmit_flag: # did not send a CC, the process a knob twist
                            app.root.ids.sm.get_screen('editor').ids.editor.process_cc(msg.control, msg.value)
                        self.cc_xmit_flag = False  # clear the flag, a cc was xmitted and received.
                elif msg.type == 'program_change' and msg.channel == self.midi_channel:
                    # print('PC command received')
                    if not self.startup: # suppress UI requests on startup
                        self.send_command(SYSEX.ui_state_req)
                    elif self.startup is True:
                        self.lppup.set_value(msg.program)
                        if msg.program == 16:  # suppress UI requests on startup
                            self.startup = False  # statup is complete
                            self.lppup.dismiss()
                        # print(f'_midi_time_delay:{self._midi_time_delay * 1000} ms')
                elif msg.type == 'sysex' and msg.data[0:6] == (0x00, 0x20, 0x10, self.midi_channel, 0x01, 0x03):
                    # print(f'Sysex received {msg.data} midi_channel: {self.midi_channel}') # msg.data[6] is the sysex command byte
                    h = Header(*msg.data[0:7])
                    try:
                        if h.cmd == SYSEX.ui_state_recv.value:
                            app.is_connected = True # receving the ui message means we are on the correct midi channel
                            p = Patch(*msg.data)
                            # print(f'UI Received:{p}')
                            app.root.ids.sm.get_screen('editor').ids.editor.process_ui(msg.data)
                        elif h.cmd == SYSEX.patch_send.value: # response to patch request
                            # print(f'preset number:{msg.data[7]} patch data{msg.data[8:]}')
                            app.mylib.set_preset_label(msg.data[7], msg.data[8:]) # send headless patch data to librarian
                        elif h.cmd == SYSEX.globals_recv.value:
                            app.root.ids.sm.get_screen('globals').ids.enzo_globals.process_globals(msg.data)
                    except TypeError:
                        #  Certain tap patterns can cause a short packet, log the issue
                        Logger.exception(f'APPLICATION: Invaid MIDI SYSEX Message received: {msg}')

                        # app.error_popup.ids.message.text = 'Invalid Message Received: Enzo HW Reset Required.\n\n' + \
                        #     'Holding down the “Synth Mode” button on power-up resets all of the presets and all of ' + \
                        #     'the global settings back to their original factory values.\n\n Once the reset is complete, '+ \
                        #     'simply recycle the power on the unit. \n\nThen on the Enzo follow the directions to set ' +\
                        #     'the Global Configuration settings of the Expression mode to MIDI, and set the midi channel.'
                        # app.error_popup.open()

class LoadPresetsPopup(Popup):
    def set_value(self, value):
        self.ids.pb_status.value = value


class ConnectMidiPopup(Popup):
    """Selects the MIDI Port and MIDI Channel."""
    directions = StringProperty(
"""Be sure that Enzo is set up for use.  On the Enzo set the following global settings:
1) Set Expression mode to MIDI\n2) Set MIDI Thru to MIDI Out\n3) Set the Midi Channel to match the midi channel setting in the editor, as set below\n
Select the Help/Enzo Manual for directions on setting these Global Parameters on the Enzo""")
    def scan_midi_ports(self):
        # Read all midi interfaces, put the names into the dialog
        mainapp = App.get_running_app()
        em = mainapp.enzo_midi
        em.get_midi_ports()
        # print(f"MIDI input:{em.midi_in_names}  output: {em.midi_out_names}")
        if em.midi_in_names:
            self.ids.midi_in.values = em.midi_in_names  # populate spinners with midi port names
            self.ids.midi_in.text = em.midi_in_names[0]
            self.ids.midi_out.values = em.midi_out_names
            self.ids.midi_out.text = em.midi_out_names[0]
            # print(f'Midi Channel is {em.midi_channel}')
            self.ids.midi_ch.text = str(em.midi_channel + 1) if em.midi_channel in range(0, 16) else 'None'

    def connect_to_midi(self):
        # connect to the selected midi interface and channel
        mainapp = App.get_running_app()
        em = mainapp.enzo_midi
        em.set_midi(self.ids.midi_ch.text, self.ids.midi_in.text, self.ids.midi_out.text)
        self.dismiss()


def midi_dialog():
    cmp = ConnectMidiPopup()
    cmp.scan_midi_ports()
    cmp.open()


if __name__ == '__main__':
    kv_test = '''
TestButton:
    Button:
        text: 'Press me for Midi PopUp'
        on_release: root.open_midi_dialog()
    BoxLayout:
        orientation: 'vertical'
        Button:
            text: 'Pitch +24'
            on_release: app.enzo_midi.cc(app.cc.pitch, 0x7F)
        Button:
            text: 'Pitch +12'
            on_release: app.enzo_midi.cc(app.cc.pitch, 0x74)
        Button:
            text: 'Pitch 0'
            on_release: app.enzo_midi.cc(app.cc.pitch, 0x38) 
        Button:
            text: 'Pitch -12'
            on_release: app.enzo_midi.cc(app.cc.pitch, 0x01) 
        Button:
            text: 'Pitch -24' 
            on_release: app.enzo_midi.cc(app.cc.pitch, 0x00)
        Button:
            text: 'Press to request UI'
            on_release: root.get_ui()
    
    BoxLayout:
        orientation: 'vertical'
        Spinner:
            id: pc_value
            text: 'Select a Preset'
            values: [str(x) for x in range(1,17)]
            on_text: app.enzo_midi.pc(int(self.text))
        Button:
            text: 'Preview Patch PolySwell'
            on_release: root.preview_polyswell()
        Button:
            text: 'Write Patch 1 with Polyswell'
            on_release: root.write_polyswell(1)
        
        Button:
            text: 'TRS Input on'
            on_release: root.set_trs(1)
        Button:
            text: 'TRS Input off'
            on_release: root.set_trs(0)
'''
    polyswell = [0x01, 0x06, 0x7B, 0x7F, 0x21, 0x7B, 0x39, 0x00, 0x54, 0x7F, 0x00, 0x66, 0x00, 0x7F, 0x00,
                 0x7F, 0x00, 0x7F, 0x40, 0x7B, 0x7F, 0x21, 0x7B, 0x39, 0x00, 0x54, 0x7F, 0x00, 0x66, 0x00]

    class TestButton(BoxLayout):
        def open_midi_dialog(self):
            midi_dialog()

        def get_ui(self):
            MidiTestApp.enzo_midi.send_command(SYSEX.ui_state_req)

        def set_trs(self, val):
            gv = GlobalVal.on if val else GlobalVal.off
            MidiTestApp.enzo_midi.write_global(GlobalAdr.trs_in, gv)

        def set_pitch(self, val):
            MidiTestApp.enzo_midi.cc(CC.pitch, val)

        def preview_polyswell(self):
            MidiTestApp.enzo_midi.preview_patch(polyswell)

        def write_polyswell(self, preset):
            MidiTestApp.enzo_midi.write_patch(preset,polyswell)


    class MidiTestApp(App):
        enzo_midi = EnzoMidi()
        cc = CC
        def build_config(self, config):   # This config code will need to migrate to the 'real' app
            config.setdefaults('MIDI', {'input': 'None',
                                        'output': 'None',
                                        'channel': 'None'})
        def build(self):
            em = MidiTestApp.enzo_midi
            config = self.config
            midi_ch = config.getdefault('MIDI', 'channel', 'None')
            midi_in = config.get('MIDI', 'input')
            midi_out = config.get('MIDI', 'output')
            em.get_midi_ports()
            if midi_ch != 'None' and midi_in in em.midi_in_names and midi_out in em.midi_out_names:
                em.set_midi(midi_ch, midi_in, midi_out)
            return Builder.load_string(kv_test)

        def on_stop(self):
            em = MidiTestApp.enzo_midi
            config = self.config
            if em.to_enzo != None:
                config.set('MIDI', 'channel', str(em.midi_channel+1))
                config.set('MIDI','input', em.midi_input)
                config.set('MIDI','output', em.midi_output)
            else:
                config.set('MIDI', 'channel', 'None')
                config.set('MIDI', 'input', 'None')
                config.set('MIDI', 'output', 'None')
            config.write()


    MidiTestApp().run()
